// src/core/keychain.ts
import { execSync } from "child_process";
var KEYCHAIN_SERVICE = "Claude Code-credentials";
function readProviderHint() {
  const raw = process.env.ASSRT_PROVIDER?.trim().toLowerCase();
  if (!raw) return null;
  if (raw === "anthropic" || raw === "claude") return "anthropic";
  if (raw === "gemini" || raw === "google") return "gemini";
  if (raw === "codex" || raw === "openai" || raw === "chatgpt") return "codex";
  console.error(`[auth] Unknown ASSRT_PROVIDER='${raw}', ignoring hint and falling back to priority chain`);
  return null;
}
function readClaudeOAuthToken() {
  if (process.platform !== "darwin") return null;
  try {
    const raw = execSync(
      `security find-generic-password -s "${KEYCHAIN_SERVICE}" -w`,
      { encoding: "utf-8", timeout: 5e3, stdio: ["pipe", "pipe", "pipe"] }
    ).trim();
    const parsed = JSON.parse(raw);
    return parsed?.claudeAiOauth?.accessToken ?? null;
  } catch {
    return null;
  }
}
function getCredential() {
  const hint = readProviderHint();
  if (hint === "gemini") {
    const geminiKey2 = process.env.GEMINI_API_KEY;
    if (geminiKey2) {
      console.error("[auth] ASSRT_PROVIDER=gemini \u2192 using GEMINI_API_KEY env var (gemini)");
      return { token: geminiKey2, type: "apiKey", provider: "gemini" };
    }
    throw new Error(
      "ASSRT_PROVIDER=gemini but GEMINI_API_KEY is not set. In Fazm, enable Gemini in Settings or switch the selected model to Claude."
    );
  }
  if (hint === "codex") {
    console.error("[auth] ASSRT_PROVIDER=codex: Codex/ChatGPT not yet supported by Assrt; falling back to Claude OAuth");
    const token = readClaudeOAuthToken();
    if (token) {
      console.error("[auth] Using Claude Code OAuth token from macOS Keychain (anthropic, codex fallback)");
      return { token, type: "oauth", provider: "anthropic" };
    }
    throw new Error(
      "ASSRT_PROVIDER=codex but Codex/ChatGPT is not yet supported by Assrt, and no Claude Code OAuth token was found in Keychain to fall back to. Sign into Claude Code (`claude` in terminal) or switch Fazm's model to Claude/Gemini."
    );
  }
  if (hint === "anthropic") {
    const token = readClaudeOAuthToken();
    if (token) {
      console.error("[auth] ASSRT_PROVIDER=anthropic \u2192 using Claude Code OAuth token from macOS Keychain");
      return { token, type: "oauth", provider: "anthropic" };
    }
    throw new Error(
      "ASSRT_PROVIDER=anthropic but no Claude Code OAuth token was found in Keychain. Sign into Claude Code (`claude` in terminal) to store one, or switch Fazm's model to Gemini."
    );
  }
  const claudeToken = readClaudeOAuthToken();
  if (claudeToken) {
    console.error("[auth] Using Claude Code OAuth token from macOS Keychain (anthropic)");
    return { token: claudeToken, type: "oauth", provider: "anthropic" };
  }
  const anthropicKey = process.env.ANTHROPIC_API_KEY;
  if (anthropicKey) {
    console.error("[auth] Using ANTHROPIC_API_KEY env var (anthropic)");
    return { token: anthropicKey, type: "apiKey", provider: "anthropic" };
  }
  const geminiKey = process.env.GEMINI_API_KEY;
  if (geminiKey) {
    console.error("[auth] Using GEMINI_API_KEY env var (gemini)");
    return { token: geminiKey, type: "apiKey", provider: "gemini" };
  }
  throw new Error(
    "No credentials found. Provide one of:\n  - Log in to Claude Code (`claude` in terminal) to store an OAuth token in Keychain (preferred), or\n  - Set ANTHROPIC_API_KEY (Anthropic fallback), or\n  - Set GEMINI_API_KEY (Gemini fallback)."
  );
}

// src/core/managed-chrome.ts
import { spawn } from "child_process";
import { existsSync, lstatSync, mkdirSync, unlinkSync } from "fs";
import { homedir } from "os";
import { join } from "path";
var CHROME_BIN_CANDIDATES = [
  // macOS
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
  "/Applications/Chromium.app/Contents/MacOS/Chromium",
  "/Applications/Google Chrome Beta.app/Contents/MacOS/Google Chrome Beta",
  // Linux
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser"
];
var DEFAULT_MANAGED_PORT = 9755;
var DEFAULT_MANAGED_USER_DATA_DIR = join(homedir(), ".assrt", "managed-chrome");
var ChromeNotFoundError = class extends Error {
  constructor() {
    super(
      "Google Chrome (or Chromium) not found. Install Chrome from https://www.google.com/chrome/, or set ASSRT_CHROME_BIN to an explicit binary path."
    );
    this.name = "ChromeNotFoundError";
  }
};
var ChromeStartupTimeout = class extends Error {
  constructor(port, timeoutMs) {
    super(`Chrome did not expose CDP on port ${port} within ${timeoutMs}ms.`);
    this.name = "ChromeStartupTimeout";
  }
};
function resolveChromeBin(explicit) {
  if (explicit && existsSync(explicit)) return explicit;
  const env = process.env.ASSRT_CHROME_BIN?.trim();
  if (env && existsSync(env)) return env;
  for (const p of CHROME_BIN_CANDIDATES) {
    if (existsSync(p)) return p;
  }
  return null;
}
async function isCdpAlive(port, timeoutMs = 1500) {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(`http://127.0.0.1:${port}/json/version`, { signal: ctrl.signal });
    clearTimeout(t);
    return res.ok;
  } catch {
    return false;
  }
}
async function waitForCdp(port, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await isCdpAlive(port, 800)) return;
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new ChromeStartupTimeout(port, timeoutMs);
}
function cleanSingletonLocks(userDataDir) {
  for (const name of ["SingletonLock", "SingletonSocket", "SingletonCookie"]) {
    const p = join(userDataDir, name);
    let exists = false;
    try {
      lstatSync(p);
      exists = true;
    } catch {
    }
    if (exists) {
      try {
        unlinkSync(p);
      } catch {
      }
    }
  }
}
async function launchManagedChrome(opts = {}) {
  const port = opts.port ?? DEFAULT_MANAGED_PORT;
  const envProfile = process.env.ASSRT_MANAGED_USER_DATA_DIR?.trim();
  const userDataDir = opts.userDataDir ?? (envProfile && envProfile.length > 0 ? envProfile : DEFAULT_MANAGED_USER_DATA_DIR);
  const headed = opts.headed ?? false;
  const startupTimeoutMs = opts.startupTimeoutMs ?? 3e4;
  const chromeBin = resolveChromeBin(opts.chromeBin);
  if (!chromeBin) throw new ChromeNotFoundError();
  const cdpUrl = `http://127.0.0.1:${port}`;
  if (await isCdpAlive(port)) {
    console.error(`[managed-chrome] attaching to existing Chrome on port ${port}`);
    return {
      pid: null,
      port,
      cdpUrl,
      userDataDir,
      chromeBin,
      headed,
      reused: true,
      close: async () => {
      }
    };
  }
  mkdirSync(userDataDir, { recursive: true });
  cleanSingletonLocks(userDataDir);
  const isFirstLaunch = !existsSync(join(userDataDir, "Default", "Preferences"));
  const args = [
    `--remote-debugging-port=${port}`,
    `--user-data-dir=${userDataDir}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-background-networking",
    "--disable-default-apps",
    "--disable-features=Translate,OptimizationHints,MediaRouter,ChromeWhatsNewUI",
    "--disable-component-update",
    "--disable-domain-reliability",
    "--disable-sync",
    "--metrics-recording-only",
    "--no-pings",
    "--password-store=basic",
    "--use-mock-keychain"
  ];
  if (isFirstLaunch) {
    args.push("--window-position=22,30", "--window-size=1134,1112");
  }
  if (!headed) args.push("--headless=new");
  console.error(`[managed-chrome] spawning ${chromeBin} port=${port} headed=${headed} userDataDir=${userDataDir}`);
  const child = spawn(chromeBin, args, {
    stdio: ["ignore", "pipe", "pipe"],
    detached: false
  });
  child.on("error", (err) => {
    console.error(`[managed-chrome] spawn error: ${err.message}`);
  });
  try {
    await waitForCdp(port, startupTimeoutMs);
  } catch (err) {
    try {
      child.kill("SIGKILL");
    } catch {
    }
    throw err;
  }
  console.error(`[managed-chrome] CDP ready at ${cdpUrl} (pid=${child.pid})`);
  const handle = {
    pid: child.pid ?? null,
    port,
    cdpUrl,
    userDataDir,
    chromeBin,
    headed,
    reused: false,
    close: async () => {
      try {
        child.kill("SIGTERM");
      } catch {
      }
      for (let i = 0; i < 20; i++) {
        if (child.exitCode != null || child.killed) break;
        await new Promise((r) => setTimeout(r, 100));
      }
      if (child.exitCode == null && !child.killed) {
        try {
          child.kill("SIGKILL");
        } catch {
        }
      }
    }
  };
  return handle;
}

// src/core/browser.ts
var ExtensionTokenRequired = class extends Error {
  constructor() {
    super(
      "Extension mode requires a one-time setup token.\n\nTo set it up:\n1. Make sure Chrome is running with the Playwright MCP extension installed\n   (install from: https://chromewebstore.google.com/detail/playwright-mcp-bridge/gjloebkfhhlbhemfgnmpjafamelkidba)\n2. Run this command in your terminal:\n   npx @playwright/mcp@latest --extension\n3. Approve the connection in the Chrome dialog that appears\n4. Copy the token shown (PLAYWRIGHT_MCP_EXTENSION_TOKEN=...)\n5. Paste the token value here so I can save it for future use"
    );
    this.name = "ExtensionTokenRequired";
  }
};
var CURSOR_INJECT_SCRIPT = `
if (!window.__pias_cursor_injected) {
  window.__pias_cursor_injected = true;

  const heartbeat = document.createElement('div');
  heartbeat.id = '__pias_heartbeat';
  Object.assign(heartbeat.style, {
    position: 'fixed', bottom: '8px', right: '8px', width: '6px', height: '6px',
    borderRadius: '50%', background: 'rgba(34,197,94,0.6)', zIndex: '2147483647',
    pointerEvents: 'none',
  });
  heartbeat.animate(
    [{ opacity: 0.2, transform: 'scale(0.8)' }, { opacity: 0.8, transform: 'scale(1.2)' }],
    { duration: 800, iterations: Infinity, direction: 'alternate', easing: 'ease-in-out' }
  );
  document.body.appendChild(heartbeat);

  const cursor = document.createElement('div');
  cursor.id = '__pias_cursor';
  Object.assign(cursor.style, {
    position: 'fixed', width: '20px', height: '20px', borderRadius: '50%',
    background: 'rgba(239,68,68,0.85)', border: '2px solid white',
    boxShadow: '0 0 8px rgba(239,68,68,0.5)', zIndex: '2147483647',
    pointerEvents: 'none', transition: 'left 0.3s ease, top 0.3s ease',
    left: '-40px', top: '-40px', transform: 'translate(-50%,-50%)',
  });
  document.body.appendChild(cursor);

  const ripple = document.createElement('div');
  ripple.id = '__pias_ripple';
  Object.assign(ripple.style, {
    position: 'fixed', width: '40px', height: '40px', borderRadius: '50%',
    border: '2px solid rgba(239,68,68,0.6)', zIndex: '2147483646',
    pointerEvents: 'none', opacity: '0', transform: 'translate(-50%,-50%) scale(0.5)',
    left: '-40px', top: '-40px',
  });
  document.body.appendChild(ripple);

  const toast = document.createElement('div');
  toast.id = '__pias_toast';
  Object.assign(toast.style, {
    position: 'fixed', bottom: '20px', left: '50%', transform: 'translateX(-50%)',
    background: 'rgba(0,0,0,0.85)', color: '#22c55e', padding: '8px 16px',
    borderRadius: '8px', fontFamily: 'monospace', fontSize: '14px',
    zIndex: '2147483647', pointerEvents: 'none', opacity: '0',
    transition: 'opacity 0.2s', maxWidth: '80%', whiteSpace: 'nowrap',
    overflow: 'hidden', textOverflow: 'ellipsis', border: '1px solid rgba(34,197,94,0.3)',
  });
  document.body.appendChild(toast);

  window.__pias_moveCursor = (x, y) => {
    cursor.style.left = x + 'px'; cursor.style.top = y + 'px';
  };
  window.__pias_showClick = (x, y) => {
    cursor.style.left = x + 'px'; cursor.style.top = y + 'px';
    ripple.style.left = x + 'px'; ripple.style.top = y + 'px';
    ripple.style.opacity = '1'; ripple.style.transform = 'translate(-50%,-50%) scale(0.5)';
    setTimeout(() => { ripple.style.transform = 'translate(-50%,-50%) scale(2)'; ripple.style.opacity = '0'; }, 50);
  };
  window.__pias_showToast = (msg) => {
    toast.textContent = msg; toast.style.opacity = '1';
    clearTimeout(window.__pias_toastTimer);
    window.__pias_toastTimer = setTimeout(() => { toast.style.opacity = '0'; }, 2500);
  };
}
`;
var McpBrowserManager = class _McpBrowserManager {
  constructor() {
    this.client = null;
    // Track cursor position server-side so it persists across navigations
    this.cursorX = 640;
    // Start roughly center-screen
    this.cursorY = 400;
    /** Directory where Playwright saves the video recording (set by launchLocal). */
    this.videoDir = null;
    /** Directory where Playwright MCP writes snapshot files in file output mode. */
    this.outputDir = null;
    /** CDP HTTP endpoint of the target browser (e.g. "http://127.0.0.1:9655"), if known.
     *  Populated when launchLocal() attaches to an externally-launched Chrome via --cdp-endpoint,
     *  or when ensureManagedChrome() launches its own Chrome. Used by seeding tools to
     *  inject cookies/localStorage/IndexedDB via ai-browser-profile.
     *  Returns null when the browser was launched in Playwright's internal-Chromium mode (no
     *  externally reachable CDP). */
    this.cdpUrl = null;
    /** Handle to a Chrome we spawned ourselves (managed mode). When non-null, we own its lifecycle
     *  and must kill it on close(). When null, either Playwright owns the browser (internal Chromium)
     *  or we attached to a Chrome someone else launched (no kill on our part). */
    this.managedChrome = null;
    /** The stdio transport for the local Playwright MCP process. */
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.transport = null;
  }
  /** Whether the MCP client reference exists (does NOT guarantee the browser is alive). */
  get isConnected() {
    return this.client != null;
  }
  /**
   * Perform a real health check by sending a lightweight tool call with a short timeout.
   * Returns true if the browser is alive and responding, false otherwise.
   */
  async isAlive() {
    if (!this.client) return false;
    try {
      await this.client.callTool(
        { name: "browser_snapshot", arguments: {} },
        void 0,
        { timeout: 5e3 }
      );
      return true;
    } catch {
      console.error("[browser] health check failed, browser is dead");
      return false;
    }
  }
  /** Get the Playwright MCP output directory path. */
  getOutputDir() {
    return this.outputDir;
  }
  getCdpUrl() {
    if (this.managedChrome) return this.managedChrome.cdpUrl;
    if (this.cdpUrl) return this.cdpUrl;
    const env = process.env.ASSRT_CDP_ENDPOINT?.trim();
    return env || null;
  }
  /** Spawn or attach to a managed Chrome with an externally reachable CDP endpoint.
   *  Idempotent: a subsequent call with a healthy managedChrome returns the existing one.
   *  After this resolves, getCdpUrl() returns a valid endpoint and seeding tools can inject. */
  async ensureManagedChrome(opts) {
    if (this.managedChrome) {
      return this.managedChrome;
    }
    this.managedChrome = await launchManagedChrome(opts);
    return this.managedChrome;
  }
  /**
   * Collect every PID associated with a given user-data-dir, from two sources:
   *  1. `ps` scan for processes with `--user-data-dir=<path>` in their command line.
   *  2. The SingletonLock symlink inside the profile (encodes `hostname-PID`), in
   *     case `ps` parsing missed the main Chrome (observed on macOS occasionally).
   *  Also walks up to include Playwright-MCP parents so the whole spawn chain dies.
   */
  static async collectProfilePids(userDataDir) {
    const { execSync: execSync2 } = await import("child_process");
    const { readlinkSync } = await import("fs");
    const { join: join3 } = await import("path");
    const pids = /* @__PURE__ */ new Set();
    try {
      const psOutput = execSync2(
        `ps aux | grep -E "user-data-dir.*${userDataDir.replace(/\//g, "\\/")}" | grep -v grep || true`,
        { encoding: "utf-8", timeout: 5e3 }
      ).trim();
      for (const line of psOutput.split("\n").filter(Boolean)) {
        const pid = parseInt(line.trim().split(/\s+/)[1], 10);
        if (pid && !isNaN(pid)) pids.add(pid);
      }
    } catch {
    }
    try {
      const target = readlinkSync(join3(userDataDir, "SingletonLock"));
      const lockPid = parseInt(target.split("-").pop() || "", 10);
      if (lockPid && !isNaN(lockPid)) pids.add(lockPid);
    } catch {
    }
    for (const pid of [...pids]) {
      try {
        const ppid = parseInt(execSync2(`ps -o ppid= -p ${pid}`, { encoding: "utf-8", timeout: 3e3 }).trim(), 10);
        if (ppid && !isNaN(ppid) && ppid > 1) {
          const parentCmd = execSync2(`ps -o command= -p ${ppid}`, { encoding: "utf-8", timeout: 3e3 }).trim();
          if (parentCmd.includes("playwright")) pids.add(ppid);
        }
      } catch {
      }
    }
    return [...pids];
  }
  /**
   * Kill every Chrome/Playwright process pinned to `userDataDir`, unconditionally.
   * Called from the full-launch path where `this.client` is null — by definition
   * we own nothing on that profile, so anything on it is an orphan regardless of
   * age or liveness. Retries once if the profile is still occupied after the first
   * sweep (covers races where a child respawns, or `ps` missed a process).
   */
  static async killOrphanChromeProcesses(userDataDir) {
    try {
      for (let attempt = 0; attempt < 2; attempt++) {
        const pids = await _McpBrowserManager.collectProfilePids(userDataDir);
        if (pids.length === 0) return;
        console.error(`[browser] attempt ${attempt + 1}: killing ${pids.length} process(es) pinned to ${userDataDir}: ${pids.join(", ")}`);
        for (const pid of pids) {
          try {
            process.kill(pid, "SIGKILL");
            console.error(`[browser] killed pid=${pid}`);
          } catch {
          }
        }
        await new Promise((r) => setTimeout(r, 750));
      }
      const remaining = await _McpBrowserManager.collectProfilePids(userDataDir);
      if (remaining.length > 0) {
        console.error(`[browser] WARNING: ${remaining.length} process(es) still pinned after 2 sweeps: ${remaining.join(", ")}`);
      }
    } catch (err) {
      console.error(`[browser] orphan cleanup error (non-fatal):`, err);
    }
  }
  static {
    /** Launch browser locally via Playwright MCP over stdio (CLI mode).
     *  @param videoDir — Optional directory for Playwright video recording. If provided, a config
     *  file is written with recordVideo enabled and passed to the MCP server via --config.
     *  @param headed — When true, launch a visible browser window. Defaults to headless.
     *  @param isolated — When true, keep browser profile in memory only (no disk persistence).
     *  When false (default), persist the browser profile to ~/.assrt/browser-profile so cookies,
     *  localStorage, and logins survive across test runs. */
    /** Saved extension token file path. */
    this.EXTENSION_TOKEN_PATH = ".assrt/extension-token";
  }
  /** Resolve the extension token from (in priority order): parameter, env var, saved file.
   *  Returns null if none found. Saves new tokens to disk for future use. */
  async resolveExtensionToken(tokenParam) {
    const { homedir: homedir2 } = await import("os");
    const { join: join3 } = await import("path");
    const tokenPath = join3(homedir2(), _McpBrowserManager.EXTENSION_TOKEN_PATH);
    if (tokenParam) {
      const { mkdirSync: mkdirSync2, writeFileSync } = await import("fs");
      mkdirSync2(join3(homedir2(), ".assrt"), { recursive: true });
      writeFileSync(tokenPath, tokenParam.trim());
      console.error("[browser] extension token saved to ~/.assrt/extension-token");
      return tokenParam.trim();
    }
    const envToken = process.env.PLAYWRIGHT_MCP_EXTENSION_TOKEN;
    if (envToken) return envToken.trim();
    try {
      const { readFileSync: readFileSync2 } = await import("fs");
      const saved = readFileSync2(tokenPath, "utf-8").trim();
      if (saved) return saved;
    } catch {
    }
    return null;
  }
  /** @returns true if an existing browser was reused, false if a new one was launched. */
  async launchLocal(videoDir, headed, isolated, extension, extensionToken, managed) {
    if (this.client) {
      if (await this.isAlive()) {
        console.error("[browser] reusing existing browser connection (health check passed)");
        if (videoDir) this.videoDir = videoDir;
        return true;
      }
      console.error("[browser] existing client failed health check \u2014 tearing down and relaunching");
      try {
        await this.client.close();
      } catch {
      }
      this.client = null;
      this.transport = null;
    }
    const { Client } = await import("@modelcontextprotocol/sdk/client/index.js");
    const { StdioClientTransport } = await import("@modelcontextprotocol/sdk/client/stdio.js");
    const { dirname: dirname2, join: join3 } = await import("path");
    const { tmpdir, homedir: homedir2 } = await import("os");
    const { createRequire } = await import("module");
    const require_ = createRequire(import.meta.url);
    const pkgDir = dirname2(require_.resolve("@playwright/mcp/package.json"));
    const cliPath = join3(pkgDir, "cli.js");
    console.error("[browser] spawning local Playwright MCP via stdio");
    const tConn = Date.now();
    const outputDir = join3(homedir2(), ".assrt", "playwright-output");
    const { mkdirSync: mkdirSync2 } = await import("fs");
    mkdirSync2(outputDir, { recursive: true });
    this.outputDir = outputDir;
    const args = [cliPath, "--viewport-size", "1600x900", "--output-mode", "file", "--output-dir", outputDir, "--caps", "devtools"];
    let cdpEndpoint = this.managedChrome?.cdpUrl;
    if (!cdpEndpoint && managed) {
      const handle = await this.ensureManagedChrome({ headed });
      cdpEndpoint = handle.cdpUrl;
    }
    if (!cdpEndpoint) cdpEndpoint = process.env.ASSRT_CDP_ENDPOINT?.trim() || void 0;
    let resolvedExtensionToken = null;
    if (cdpEndpoint) {
      args.push("--cdp-endpoint", cdpEndpoint);
      console.error(`[browser] launch mode: cdp-attach to ${cdpEndpoint}`);
    } else if (extension) {
      resolvedExtensionToken = await this.resolveExtensionToken(extensionToken);
      if (!resolvedExtensionToken) {
        throw new ExtensionTokenRequired();
      }
      args.push("--extension");
      console.error("[browser] launch mode: extension (connecting to existing Chrome)");
    } else if (isolated) {
      args.push("--isolated");
      console.error("[browser] profile mode: isolated (in-memory, no persistence)");
    } else {
      const { lstatSync: lstatSync2, unlinkSync: unlinkSync2, readlinkSync, writeFileSync } = await import("fs");
      const { execSync: execSync2 } = await import("child_process");
      const userDataDir = join3(homedir2(), ".assrt", "browser-profile");
      mkdirSync2(userDataDir, { recursive: true });
      await _McpBrowserManager.killOrphanChromeProcesses(userDataDir);
      const singletonFiles = ["SingletonLock", "SingletonSocket", "SingletonCookie"];
      for (const name of singletonFiles) {
        const lockPath = join3(userDataDir, name);
        let hasLock = false;
        try {
          lstatSync2(lockPath);
          hasLock = true;
        } catch {
        }
        if (hasLock) {
          try {
            unlinkSync2(lockPath);
            console.error(`[browser] removed stale ${name} from browser profile`);
          } catch {
            console.error(`[browser] could not remove ${name}, falling back to isolated mode`);
            args.push("--isolated");
            isolated = true;
            break;
          }
        }
      }
      if (!isolated) {
        args.push("--user-data-dir", userDataDir);
        console.error(`[browser] profile mode: persistent (${userDataDir})`);
      }
    }
    if (!extension && !cdpEndpoint) {
      if (!headed) args.splice(1, 0, "--headless");
      console.error(`[browser] launch mode: ${headed ? "headed" : "headless"}`);
    }
    if (videoDir) {
      this.videoDir = videoDir;
    }
    const transportEnv = {};
    for (const [k, v] of Object.entries(process.env)) {
      if (typeof v === "string") transportEnv[k] = v;
    }
    if (resolvedExtensionToken) {
      transportEnv.PLAYWRIGHT_MCP_EXTENSION_TOKEN = resolvedExtensionToken;
    }
    this.transport = new StdioClientTransport({
      command: process.execPath,
      args,
      stderr: "pipe",
      env: transportEnv
    });
    this.client = new Client(
      { name: "assrt", version: "1.0.0" },
      { capabilities: {} }
    );
    await this.client.connect(this.transport);
    console.error(
      `[browser] local MCP connected in ${((Date.now() - tConn) / 1e3).toFixed(1)}s`
    );
    return false;
  }
  static {
    /** Per-call timeout for MCP tool requests (overrides the SDK's 60s default). */
    this.TOOL_TIMEOUT_MS = 12e4;
  }
  /** Call a Playwright MCP tool by name.
   *  Uses a 120s timeout (vs the SDK's 60s default) to give slow navigations room,
   *  and detects connection failures so callers can trigger reconnection. */
  async callTool(name, args = {}) {
    if (!this.client) throw new Error("MCP client not connected");
    const t = Date.now();
    const argSummary = name === "browser_navigate" ? ` url=${args.url}` : name === "browser_type" ? ` text=${JSON.stringify(args.text).slice(0, 40)}` : name === "browser_click" ? ` el=${JSON.stringify(args.element).slice(0, 40)}` : "";
    try {
      const result = await this.client.callTool(
        { name, arguments: args },
        void 0,
        { timeout: _McpBrowserManager.TOOL_TIMEOUT_MS }
      );
      const dt = Date.now() - t;
      const err = result.isError ? " ERROR" : "";
      console.error(`[mcp] ${name}${argSummary} (${dt}ms)${err}`);
      return result;
    } catch (e) {
      const msg = e.message ?? "";
      const dt = Date.now() - t;
      console.error(`[mcp] ${name}${argSummary} THREW after ${dt}ms: ${msg}`);
      if (msg.includes("Request timed out") || msg.includes("-32001") || msg.includes("EPIPE") || msg.includes("not connected")) {
        console.error("[browser] marking client as dead after transport/timeout error");
        this.client = null;
        this.transport = null;
      }
      throw e;
    }
  }
  // ── Visual overlay helpers ──
  /** Inject cursor + toast overlays into the page (safe to call multiple times).
   *  After injection, restores cursor to its last known position instantly
   *  (no transition) so it doesn't animate from off-screen. */
  async injectOverlay() {
    try {
      await this.callTool("browser_evaluate", {
        "function": `() => {
          ${CURSOR_INJECT_SCRIPT}
          // Restore cursor to last known position without animation
          const c = document.getElementById('__pias_cursor');
          if (c) {
            c.style.transition = 'none';
            c.style.left = '${this.cursorX}px';
            c.style.top = '${this.cursorY}px';
            // Re-enable smooth transition after a tick
            setTimeout(() => { c.style.transition = 'left 0.3s ease, top 0.3s ease'; }, 50);
          }
        }`
      });
    } catch {
    }
  }
  /** Move cursor smoothly to an element and show click ripple.
   *  The cursor glides from its previous position via CSS transition.
   *  Updates the tracked position so it persists across navigations. */
  async showClickAt(element, ref) {
    try {
      await this.injectOverlay();
      const sel = JSON.stringify(element);
      const result = await this.callTool("browser_evaluate", {
        "function": `() => {
          const sel = ${sel};
          const selLower = sel.toLowerCase();
          let el = null;
          try { el = document.querySelector(sel); } catch {}
          if (!el) {
            const candidates = document.querySelectorAll('a, button, input, [role="button"], select, textarea, label, [onclick], [href]');
            const words = selLower.split(/\\s+/).filter(w => w.length > 2);
            let bestScore = 0;
            for (const e of candidates) {
              const txt = (e.textContent || '').trim().toLowerCase();
              if (!txt) continue;
              if (txt === selLower) { el = e; break; }
              let score = 0;
              if (txt.includes(selLower)) score = 3;
              else if (selLower.includes(txt) && txt.length > 2) score = 2;
              else {
                const matched = words.filter(w => txt.includes(w)).length;
                if (matched > 0) score = matched / words.length;
              }
              if (score > bestScore) { bestScore = score; el = e; }
            }
          }
          if (el) {
            const r = el.getBoundingClientRect();
            const x = r.left + r.width / 2;
            const y = r.top + r.height / 2;
            window.__pias_showClick?.(x, y);
            return JSON.stringify({ x, y });
          }
          return null;
        }`
      });
      const text = extractText(result);
      if (text) {
        try {
          const parsed = JSON.parse(text.replace(/^.*?(\{.*\}).*$/, "$1"));
          if (parsed && typeof parsed.x === "number") {
            this.cursorX = Math.round(parsed.x);
            this.cursorY = Math.round(parsed.y);
          }
        } catch {
        }
      }
    } catch {
    }
  }
  /** Show a keystroke toast at the bottom of the page. */
  async showKeystroke(label) {
    try {
      await this.injectOverlay();
      await this.callTool("browser_evaluate", {
        "function": `() => { window.__pias_showToast?.(${JSON.stringify(label)}); }`
      });
    } catch {
    }
  }
  // ── Convenience methods mapping to Playwright MCP tools ──
  async navigate(url) {
    const result = await this.callTool("browser_navigate", { url });
    await this.injectOverlay();
    return this.resolveAndTruncate(extractText(result));
  }
  static {
    /** Max characters for a snapshot before truncation (roughly ~30k tokens). */
    this.SNAPSHOT_MAX_CHARS = 12e4;
  }
  /**
   * Resolve file references in Playwright MCP output (file output mode) and
   * truncate large snapshots to avoid blowing up the agent's context window.
   */
  async resolveAndTruncate(text) {
    if (this.outputDir && text.includes(".yml")) {
      const match = text.match(/([^\s"]+\.yml)/);
      if (match) {
        const filePath = match[1];
        const { readFileSync: readFileSync2 } = await import("fs");
        const { resolve } = await import("path");
        const fullPath = filePath.startsWith("/") ? filePath : resolve(this.outputDir, filePath);
        try {
          text = readFileSync2(fullPath, "utf-8");
        } catch {
        }
      }
    }
    if (text.length > _McpBrowserManager.SNAPSHOT_MAX_CHARS) {
      const originalLen = text.length;
      const truncated = text.slice(0, _McpBrowserManager.SNAPSHOT_MAX_CHARS);
      const lineBreak = truncated.lastIndexOf("\n");
      text = (lineBreak > 0 ? truncated.slice(0, lineBreak) : truncated) + `

[Snapshot truncated: showing ${(_McpBrowserManager.SNAPSHOT_MAX_CHARS / 1e3).toFixed(0)}k of ${(originalLen / 1e3).toFixed(0)}k chars. Use element refs visible above to interact.]`;
      console.error(`[browser] snapshot truncated: ${_McpBrowserManager.SNAPSHOT_MAX_CHARS} chars (original: ${originalLen})`);
    }
    return text;
  }
  async snapshot() {
    const result = await this.callTool("browser_snapshot");
    return this.resolveAndTruncate(extractText(result));
  }
  async click(element, ref) {
    await this.showClickAt(element, ref);
    await new Promise((r) => setTimeout(r, 400));
    const args = { element };
    if (ref) args.ref = ref;
    const result = await this.callTool("browser_click", args);
    return this.resolveAndTruncate(extractText(result));
  }
  async type(element, text, ref) {
    await this.showClickAt(element, ref);
    await new Promise((r) => setTimeout(r, 400));
    await this.showKeystroke(`\u2328 typing: "${text.slice(0, 40)}${text.length > 40 ? "\u2026" : ""}"`);
    const args = { element, text };
    if (ref) args.ref = ref;
    const result = await this.callTool("browser_type", args);
    return this.resolveAndTruncate(extractText(result));
  }
  async selectOption(element, values) {
    await this.showClickAt(element);
    await new Promise((r) => setTimeout(r, 400));
    const result = await this.callTool("browser_select_option", {
      element,
      values
    });
    return this.resolveAndTruncate(extractText(result));
  }
  /** Resize the browser viewport. */
  async resize(width, height) {
    await this.callTool("browser_resize", { width, height });
  }
  async screenshot() {
    const tCapture = Date.now();
    const result = await this.callTool("browser_take_screenshot", { type: "jpeg", quality: 50 });
    for (const content of result.content || []) {
      if (content.type === "image") return content.data || null;
    }
    if (!this.outputDir) return null;
    const { readFileSync: readFileSync2, readdirSync, statSync } = await import("fs");
    const { resolve, join: pathJoin } = await import("path");
    const text = extractText(result);
    const match = text.match(/([^\s"]+\.(?:jpeg|jpg|png))/i);
    if (match) {
      const filePath = match[1];
      const fullPath = filePath.startsWith("/") ? filePath : resolve(this.outputDir, filePath);
      try {
        return readFileSync2(fullPath).toString("base64");
      } catch {
      }
    }
    try {
      const files = readdirSync(this.outputDir).filter((f) => /\.(jpe?g|png)$/i.test(f)).map((f) => {
        const full = pathJoin(this.outputDir, f);
        let mtime = 0;
        try {
          mtime = statSync(full).mtimeMs;
        } catch {
        }
        return { full, mtime };
      }).filter((e) => e.mtime >= tCapture - 1e3).sort((a, b) => b.mtime - a.mtime);
      if (files.length > 0) {
        return readFileSync2(files[0].full).toString("base64");
      }
    } catch {
    }
    return null;
  }
  /** Start video recording (requires --caps devtools). */
  async startVideo(filename) {
    try {
      const args = { size: { width: 1600, height: 900 } };
      if (filename) args.filename = filename;
      await this.callTool("browser_start_video", args);
      console.error(`[browser] video recording started${filename ? `: ${filename}` : ""}`);
    } catch (err) {
      console.error(`[browser] failed to start video: ${err.message}`);
    }
  }
  /** Stop video recording and finalize the file. */
  async stopVideo() {
    try {
      await this.callTool("browser_stop_video", {});
      console.error("[browser] video recording stopped");
    } catch (err) {
      console.error(`[browser] failed to stop video: ${err.message}`);
    }
  }
  async pressKey(key) {
    await this.showKeystroke(`\u2328 key: ${key}`);
    const result = await this.callTool("browser_press_key", { key });
    return extractText(result);
  }
  async scroll(x, y) {
    const result = await this.callTool("browser_scroll", { x, y });
    return extractText(result);
  }
  async waitForText(text, timeout) {
    const args = { text };
    if (timeout) args.timeout = timeout;
    const result = await this.callTool("browser_wait_for", args);
    return extractText(result);
  }
  async evaluate(expression) {
    const fn = expression.includes("=>") ? expression : `() => (${expression})`;
    const result = await this.callTool("browser_evaluate", { "function": fn });
    return extractText(result);
  }
  async close(opts) {
    if (opts?.keepBrowserOpen) {
      console.error("[browser] keepBrowserOpen=true \u2014 leaving browser running");
      if (this.transport) {
        try {
          const pid = this.transport.pid;
          if (this.transport._process) {
            this.transport._process.unref();
            this.transport._process.stdin?.unref?.();
            this.transport._process.stdout?.unref?.();
            this.transport._process.stderr?.unref?.();
            this.transport._process = void 0;
          }
          console.error(`[browser] detached Playwright MCP process (pid=${pid})`);
        } catch {
        }
        this.transport = null;
      }
      this.client = null;
      return;
    }
    if (this.client) {
      try {
        await this.callTool("browser_close");
      } catch {
      }
      try {
        await this.client.close();
      } catch {
      }
      this.client = null;
    }
    if (this.managedChrome) {
      try {
        await this.managedChrome.close();
        console.error(`[browser] managed Chrome stopped (pid=${this.managedChrome.pid})`);
      } catch (err) {
        console.error(`[browser] managed Chrome close error: ${err.message}`);
      }
      this.managedChrome = null;
    }
  }
};
function extractText(result) {
  return (result.content || []).filter((c) => c.type === "text").map((c) => c.text || "").join("\n");
}

// src/core/agent.ts
import Anthropic from "@anthropic-ai/sdk";
import { GoogleGenAI, Type } from "@google/genai";

// src/core/email.ts
var BASE = "https://api.internal.temp-mail.io/api/v3";
async function fetchJson(url, options) {
  const res = await fetch(url, { ...options, signal: AbortSignal.timeout(15e3) });
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`API returned non-JSON (${res.status}): ${text.slice(0, 200)}`);
  }
}
var DisposableEmail = class _DisposableEmail {
  constructor(address, token) {
    this.address = address;
    this.token = token;
  }
  /** Create a new random disposable email address */
  static async create() {
    const data = await fetchJson(
      `${BASE}/email/new`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ min_name_length: 10, max_name_length: 10 })
      }
    );
    if (!data.email || !data.token) {
      throw new Error(`Invalid response: ${JSON.stringify(data)}`);
    }
    return new _DisposableEmail(data.email, data.token);
  }
  /** Check inbox for messages */
  async getMessages() {
    return fetchJson(`${BASE}/email/${this.address}/messages`);
  }
  /**
   * Wait for a new email to arrive.
   * Polls every `intervalMs` for up to `timeoutMs`.
   */
  async waitForEmail(timeoutMs = 6e4, intervalMs = 3e3) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const messages = await this.getMessages();
      if (messages.length > 0) {
        return messages[messages.length - 1];
      }
      await new Promise((r) => setTimeout(r, intervalMs));
    }
    return null;
  }
  /**
   * Wait for a verification email and extract the code from it.
   */
  async waitForVerificationCode(timeoutMs = 6e4, intervalMs = 3e3) {
    const email = await this.waitForEmail(timeoutMs, intervalMs);
    if (!email) return null;
    let plainText = email.body_text || "";
    if (!plainText && email.body_html) {
      plainText = email.body_html.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/&#?\w+;/g, " ").replace(/\s+/g, " ").trim();
    }
    const patterns = [
      /(?:code|Code|CODE)[:\s]+(\d{4,8})/,
      /(?:verification|Verification)[:\s]+(\d{4,8})/,
      /(?:OTP|otp)[:\s]+(\d{4,8})/,
      /(?:pin|PIN|Pin)[:\s]+(\d{4,8})/,
      /\b(\d{6})\b/,
      // 6-digit (most common)
      /\b(\d{4})\b/,
      // 4-digit
      /\b(\d{8})\b/
      // 8-digit
    ];
    for (const pattern of patterns) {
      const match = plainText.match(pattern);
      if (match) {
        return {
          code: match[1],
          from: email.from,
          subject: email.subject,
          body: plainText.slice(0, 5e3)
        };
      }
    }
    return {
      code: "",
      from: email.from,
      subject: email.subject,
      body: plainText.slice(0, 5e3)
    };
  }
};

// src/core/agent.ts
var MAX_STEPS_PER_SCENARIO = Infinity;
var MAX_CONVERSATION_TURNS = Infinity;
var DEFAULT_ANTHROPIC_MODEL = "claude-haiku-4-5-20251001";
var DEFAULT_GEMINI_MODEL = "gemini-flash-latest";
var TOOLS = [
  {
    name: "navigate",
    description: "Navigate to a URL.",
    input_schema: {
      type: "object",
      properties: { url: { type: "string", description: "URL to navigate to" } },
      required: ["url"]
    }
  },
  {
    name: "snapshot",
    description: "Get the accessibility tree of the current page. Returns elements with [ref=eN] references you can use for click/type. ALWAYS call this before interacting with elements.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "click",
    description: "Click an element. Use the element description from the snapshot and optionally the ref ID.",
    input_schema: {
      type: "object",
      properties: {
        element: { type: "string", description: "Human-readable element description, e.g. 'Submit button' or 'Sign In link'" },
        ref: { type: "string", description: "Exact ref from snapshot, e.g. 'e5'. Preferred when available." }
      },
      required: ["element"]
    }
  },
  {
    name: "type_text",
    description: "Type text into an input field. Clears existing content first.",
    input_schema: {
      type: "object",
      properties: {
        element: { type: "string", description: "Human-readable element description" },
        text: { type: "string", description: "Text to type" },
        ref: { type: "string", description: "Exact ref from snapshot" }
      },
      required: ["element", "text"]
    }
  },
  {
    name: "select_option",
    description: "Select an option from a dropdown.",
    input_schema: {
      type: "object",
      properties: {
        element: { type: "string", description: "Element description" },
        values: { type: "array", items: { type: "string" }, description: "Values to select" }
      },
      required: ["element", "values"]
    }
  },
  {
    name: "scroll",
    description: "Scroll the page. Positive y scrolls down, negative scrolls up.",
    input_schema: {
      type: "object",
      properties: {
        x: { type: "number", description: "Horizontal scroll pixels (default: 0)" },
        y: { type: "number", description: "Vertical scroll pixels (default: 400 for down, -400 for up)" }
      },
      required: ["y"]
    }
  },
  {
    name: "press_key",
    description: "Press a keyboard key. E.g. Enter, Tab, Escape.",
    input_schema: {
      type: "object",
      properties: { key: { type: "string", description: "Key to press" } },
      required: ["key"]
    }
  },
  {
    name: "wait",
    description: "Wait for text to appear on the page, or wait a fixed duration.",
    input_schema: {
      type: "object",
      properties: {
        text: { type: "string", description: "Text to wait for (preferred)" },
        ms: { type: "number", description: "Milliseconds to wait (fallback, max 10000)" }
      }
    }
  },
  {
    name: "screenshot",
    description: "Take a screenshot of the current page.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "evaluate",
    description: "Run JavaScript in the browser and return the result.",
    input_schema: {
      type: "object",
      properties: { expression: { type: "string", description: "JavaScript expression to evaluate" } },
      required: ["expression"]
    }
  },
  {
    name: "create_temp_email",
    description: "Create a disposable email address. Use BEFORE filling signup forms.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "wait_for_verification_code",
    description: "Wait for a verification/OTP code at the disposable email. Polls up to 60s.",
    input_schema: {
      type: "object",
      properties: { timeout_seconds: { type: "number", description: "Max seconds to wait (default 60)" } }
    }
  },
  {
    name: "check_email_inbox",
    description: "Check the disposable email inbox.",
    input_schema: { type: "object", properties: {} }
  },
  {
    name: "assert",
    description: "Make a test assertion about the current page state.",
    input_schema: {
      type: "object",
      properties: {
        description: { type: "string", description: "What you are asserting" },
        passed: { type: "boolean", description: "Whether the assertion passed" },
        evidence: { type: "string", description: "Evidence for the result" }
      },
      required: ["description", "passed", "evidence"]
    }
  },
  {
    name: "complete_scenario",
    description: "Mark the current test scenario as complete.",
    input_schema: {
      type: "object",
      properties: {
        summary: { type: "string", description: "Summary of what was tested" },
        passed: { type: "boolean", description: "Whether the scenario passed overall" }
      },
      required: ["summary", "passed"]
    }
  },
  {
    name: "suggest_improvement",
    description: "Report an obvious bug or UX issue in the application.",
    input_schema: {
      type: "object",
      properties: {
        title: { type: "string", description: "Short title" },
        severity: { type: "string", description: "critical, major, or minor" },
        description: { type: "string", description: "What is wrong" },
        suggestion: { type: "string", description: "How to fix it" }
      },
      required: ["title", "severity", "description", "suggestion"]
    }
  },
  {
    name: "http_request",
    description: "Make an HTTP request to an external API. Use for verifying webhooks, polling APIs (Telegram, Slack, GitHub), or any external service interaction.",
    input_schema: {
      type: "object",
      properties: {
        url: { type: "string", description: "Full URL to request" },
        method: { type: "string", description: "HTTP method: GET, POST, PUT, DELETE (default: GET)" },
        headers: { type: "object", description: "Request headers as key-value pairs" },
        body: { type: "string", description: "Request body (JSON string for POST/PUT)" }
      },
      required: ["url"]
    }
  },
  {
    name: "wait_for_stable",
    description: "Wait until the page content stops changing (no new DOM mutations for the specified stable period). Use after triggering async actions like chat AI responses, loading states, or search results populating.",
    input_schema: {
      type: "object",
      properties: {
        timeout_seconds: { type: "number", description: "Max seconds to wait (default 30)" },
        stable_seconds: { type: "number", description: "Seconds of no DOM changes to consider stable (default 2)" }
      }
    }
  }
];
var SYSTEM_PROMPT = `You are an automated web testing agent called Assrt. Your job is to systematically test web applications by executing test scenarios.

## How You Work
1. You receive test scenario(s) to execute on a web application
2. You interact with the page using the provided tools
3. You verify expected behavior using assertions
4. You report results clearly

## CRITICAL Rules
- ALWAYS call snapshot FIRST to get the accessibility tree with element refs
- Use the ref IDs from snapshots (e.g. ref="e5") when clicking or typing. This is faster and more reliable than text matching.
- After each action, call snapshot again to see the updated page state
- Make assertions to verify expected behavior (use the assert tool)
- Call complete_scenario when done

## Selector Strategy (Playwright MCP refs)
1. Call snapshot to get the accessibility tree
2. Find the element you want to interact with in the tree
3. Use its ref value (e.g. "e5") in the ref parameter of click/type_text
4. Also provide a human-readable element description for logging
5. If a ref is stale (action fails), call snapshot again to get fresh refs

## Error Recovery
When an action fails:
1. Call snapshot to see what is currently on the page
2. The page may have changed (modal appeared, navigation happened)
3. Try using a different ref or approach
4. If stuck after 3 attempts, scroll and retry
5. If truly stuck, mark as failed with evidence and call complete_scenario

## Email Verification Strategy
When you encounter a login/signup form that requires an email:
1. FIRST call create_temp_email to get a disposable email
2. Use THAT email in the signup form
3. After submitting, call wait_for_verification_code for the OTP
4. Enter the verification code into the form
   - IMPORTANT: If the code input is split across multiple single-character fields (common OTP pattern), you MUST use evaluate to paste all digits at once. Do NOT type into each field one by one. Call evaluate with EXACTLY this expression (only replace CODE_HERE with the actual code):
     \`() => { const inp = document.querySelector('input[maxlength="1"]'); if (!inp) return 'no otp input found'; const c = inp.parentElement; const dt = new DataTransfer(); dt.setData('text/plain', 'CODE_HERE'); c.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles: true, cancelable: true})); return 'pasted ' + document.querySelectorAll('input[maxlength="1"]').length + ' fields'; }\`
     Do NOT modify this expression except to replace CODE_HERE. Do NOT use ref attributes as DOM selectors (they don't exist in the DOM). After evaluate returns "pasted", call snapshot to verify all digits filled, then click Verify.

## Scenario Continuity
- Scenarios run in the SAME browser session
- Cookies, auth state carry over between scenarios
- Take advantage of existing state rather than starting from scratch

## External API Verification
When testing integrations (Telegram, Slack, GitHub, etc.):
1. Use http_request to call external APIs (e.g. poll Telegram Bot API for messages)
2. This lets you verify that actions in the web app produced the expected external effect
3. Example: after connecting Telegram in a web app, use http_request to call https://api.telegram.org/bot<token>/getUpdates to verify messages arrived

## Waiting for Async Content
When the page has loading states, streaming AI responses, or async content:
1. Use wait_for_stable to wait until the DOM stops changing
2. This is better than wait with a fixed time because it adapts to actual load speed
3. Use it after submitting forms, sending chat messages, or triggering any async operation
4. Then call snapshot to see the final state

## Assertion Coverage (CRITICAL \u2014 non-negotiable)
Every line in the scenario steps that starts with "Verify", "Check", "Assert", "Confirm", or "Ensure" is a MANDATORY assertion. You MUST produce exactly one assert tool call for each such line.
- Do NOT silently merge two bullets into one assert call. One bullet, one assert.
- Do NOT skip a bullet because it seems redundant, obvious, or hard to check. If verifying it is genuinely impossible (e.g. the element does not exist on the page), make an assert call with passed=false and evidence describing what was missing. Failure to verify is a FAILED assertion, not a reason to omit.
- Do NOT add extra assertions that were not in the scenario steps. Cover exactly what was asked for, no more.
- Before calling complete_scenario, mentally re-read each "Verify"/"Check"/"Assert"/"Confirm"/"Ensure" line in the scenario and confirm you have made one corresponding assert call. If any are missing, make them now.
- The description field of each assert call MUST closely match the wording of the bullet it covers, so a reviewer can match assertions to bullets one-to-one.`;
var DISCOVERY_SYSTEM_PROMPT = `You are a QA engineer generating quick test cases for an AI browser agent that just landed on a new page. The agent can click, type, scroll, and verify visible text.

## Output Format
#Case 1: [short name]
[1-2 lines: what to click/type and what to verify]

## Rules
- Generate only 1-2 cases
- Each case must be completable in 3-4 actions max
- Reference ACTUAL buttons/links/inputs visible on the page
- Do NOT generate login/signup cases
- Do NOT generate cases about CSS, responsive layout, or performance`;
var MAX_CONCURRENT_DISCOVERIES = 3;
var MAX_DISCOVERED_PAGES = 20;
var SKIP_URL_PATTERNS = [/\/logout/i, /\/api\//i, /^javascript:/i, /^about:blank/i, /^data:/i, /^chrome/i];
var GEMINI_FUNCTION_DECLARATIONS = TOOLS.map((t) => ({
  name: t.name,
  description: t.description,
  parameters: {
    type: Type.OBJECT,
    properties: Object.fromEntries(
      Object.entries(t.input_schema.properties || {}).map(
        ([k, v]) => {
          const vTyped = v;
          let gType;
          if (vTyped.type === "boolean") gType = Type.BOOLEAN;
          else if (vTyped.type === "number") gType = Type.NUMBER;
          else if (vTyped.type === "array") gType = Type.ARRAY;
          else gType = Type.STRING;
          const entry = { type: gType, description: vTyped.description || "" };
          if (vTyped.type === "array" && vTyped.items) {
            entry.items = { type: Type.STRING };
          }
          return [k, entry];
        }
      )
    ),
    required: t.input_schema.required || []
  }
}));
var TestAgent = class {
  constructor(apiKey, emit, model, provider, broadcastFrame, mode, authType, videoDir, headed, isolated, browser, extension, extensionToken, managed) {
    this.anthropic = null;
    this.gemini = null;
    this.tempEmail = null;
    this.discoveredUrls = /* @__PURE__ */ new Set();
    this.activeDiscoveries = 0;
    this.browserBusy = false;
    this.pendingDiscoveryUrls = [];
    this.broadcastFrame = null;
    /**
     * @param broadcastFrame — Optional callback for CDP screencast frames.
     *   When provided, replaces the old 1.5s screenshot polling with continuous
     *   ~15fps streaming. When absent (e.g., plan generation), falls back to
     *   SSE screenshot emits.
     * @param mode — "local" spawns a local Playwright MCP over stdio.
     */
    /**
     * @param authType — "apiKey" for regular API keys (X-Api-Key header),
     *   "oauth" for Claude Code OAuth tokens (Authorization: Bearer + beta header).
     */
    /** Directory for video recording output. Only used in local mode. */
    this.videoDir = null;
    /** When true, launches a headed (visible) browser in local mode. */
    this.headed = false;
    /** When true, browser profile is in-memory only (no disk persistence). */
    this.isolated = false;
    /** When true, connect to an existing Chrome instance via Playwright's --extension flag. */
    this.extension = false;
    /** When true, launch a managed Chrome with --remote-debugging-port and attach Playwright MCP
     *  via --cdp-endpoint. Required when this run will also call seeding tools that inject via CDP. */
    this.managed = false;
    /** In-flight run state. Lets callers recover partial results if Promise.race rejects on timeout. */
    this.currentRun = null;
    this.provider = provider === "gemini" ? "gemini" : "anthropic";
    this.browser = browser || new McpBrowserManager();
    this.emit = emit;
    this.broadcastFrame = broadcastFrame || null;
    this.mode = "local";
    this.videoDir = videoDir || null;
    this.headed = !!headed;
    this.isolated = !!isolated;
    this.extension = !!extension;
    this.extensionToken = extensionToken;
    this.managed = !!managed;
    if (this.provider === "gemini") {
      this.gemini = new GoogleGenAI({ apiKey });
      this.model = model || process.env.GEMINI_MODEL || DEFAULT_GEMINI_MODEL;
    } else {
      if (authType === "oauth") {
        this.anthropic = new Anthropic({
          authToken: apiKey,
          defaultHeaders: { "anthropic-beta": "oauth-2025-04-20" }
        });
      } else {
        this.anthropic = new Anthropic({ apiKey });
      }
      this.model = model || process.env.ANTHROPIC_MODEL || DEFAULT_ANTHROPIC_MODEL;
    }
  }
  /** Snapshot of the in-flight scenario results. Returns null if no run is active. */
  getPartialReport() {
    if (!this.currentRun) return null;
    const { url, startTime, results } = this.currentRun;
    return {
      url,
      scenarios: [...results],
      totalDuration: Date.now() - startTime,
      passedCount: results.filter((r) => r.passed).length,
      failedCount: results.filter((r) => !r.passed).length,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  async run(url, scenariosText, options) {
    const startTime = Date.now();
    const passCriteria = options?.passCriteria;
    const variables = options?.variables;
    const viewport = options?.viewport;
    if (variables && Object.keys(variables).length > 0) {
      for (const [key, value] of Object.entries(variables)) {
        scenariosText = scenariosText.replace(new RegExp(`\\{\\{${key}\\}\\}`, "g"), value);
      }
    }
    console.error(JSON.stringify({ event: "agent.run.start", url, mode: this.mode, model: this.model, hasPassCriteria: !!passCriteria, variableCount: variables ? Object.keys(variables).length : 0, ts: (/* @__PURE__ */ new Date()).toISOString() }));
    this.emit("status", { message: `Checking ${url}...` });
    await this.preflightUrl(url);
    let browserReused = false;
    this.emit("status", { message: this.extension ? "Connecting to existing Chrome..." : "Launching local browser..." });
    browserReused = await this.browser.launchLocal(this.videoDir || void 0, this.headed, this.isolated, this.extension, this.extensionToken, this.managed);
    const launchMs = Date.now() - startTime;
    console.error(JSON.stringify({ event: "agent.browser.launched", durationMs: launchMs, ts: (/* @__PURE__ */ new Date()).toISOString() }));
    this.emit("status", { message: "Browser launched via Playwright MCP" });
    if (viewport) {
      const VIEWPORT_PRESETS = {
        mobile: { width: 375, height: 812 },
        desktop: { width: 1440, height: 900 }
      };
      const dims = typeof viewport === "string" ? VIEWPORT_PRESETS[viewport.toLowerCase()] : viewport;
      if (dims) {
        await this.browser.resize(dims.width, dims.height);
        this.emit("status", { message: `Viewport set to ${dims.width}x${dims.height}` });
      }
    }
    const screencastUrl = this.browser.screencastUrl;
    if (screencastUrl) {
      this.emit("screencast_url", { url: screencastUrl });
    }
    const inputUrl = this.browser.inputUrl;
    if (inputUrl) {
      this.emit("input_url", { url: inputUrl });
    }
    const vncUrl = this.browser.vncUrl;
    if (vncUrl) {
      this.emit("vnc_url", { url: vncUrl });
    }
    const vmId = this.browser.vmId;
    if (vmId) {
      this.emit("vm_id", { vmId });
    }
    const tNav = Date.now();
    const NAV_TIMEOUT_MS = 3e4;
    try {
      await Promise.race([
        this.browser.navigate(url),
        new Promise((_, reject) => setTimeout(
          () => reject(new Error(`Navigate to ${url} timed out after ${NAV_TIMEOUT_MS}ms`)),
          NAV_TIMEOUT_MS
        ))
      ]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      console.error(JSON.stringify({ event: "agent.navigate.fail", url, error: msg, durationMs: Date.now() - tNav, ts: (/* @__PURE__ */ new Date()).toISOString() }));
      throw new Error(`Failed to load ${url}: ${msg}. The page may be too slow, or the server may have stopped responding after the initial connection.`);
    }
    console.error(JSON.stringify({ event: "agent.navigate.done", url, durationMs: Date.now() - tNav, browserReused, ts: (/* @__PURE__ */ new Date()).toISOString() }));
    this.emit("status", { message: `Navigated to ${url}` });
    this.queueDiscoverPage(url);
    const scenarios = this.parseScenarios(scenariosText);
    const results = [];
    const stopOnFirstFailure = options?.stopOnFirstFailure === true;
    this.currentRun = { url, startTime, results };
    let aborted = false;
    let abortReason;
    try {
      for (let i = 0; i < scenarios.length; i++) {
        const scenario = scenarios[i];
        this.emit("scenario_start", { index: i, name: scenario.name, total: scenarios.length });
        try {
          const result = await this.runScenario(
            url,
            scenario.name,
            scenario.steps,
            i === 0,
            results.map((r) => `${r.name}: ${r.passed ? "PASSED" : "FAILED"} \u2014 ${r.summary}`),
            browserReused,
            passCriteria,
            variables
          );
          results.push(result);
          this.emit("scenario_complete", { index: i, name: scenario.name, passed: result.passed, summary: result.summary });
          await this.flushDiscovery().catch(() => {
          });
          if (stopOnFirstFailure && !result.passed) {
            aborted = true;
            abortReason = `stopOnFirstFailure: scenario "${scenario.name}" failed; skipping remaining ${scenarios.length - i - 1} scenarios.`;
            this.emit("reasoning", { text: abortReason });
            break;
          }
        } catch (scenarioErr) {
          const errMsg = scenarioErr instanceof Error ? scenarioErr.message : String(scenarioErr);
          this.emit("reasoning", { text: `Scenario "${scenario.name}" crashed: ${errMsg}. Moving to next scenario.` });
          const failedResult = {
            name: scenario.name,
            passed: false,
            steps: [],
            assertions: [],
            summary: `Error: ${errMsg.slice(0, 200)}`,
            duration: 0
          };
          results.push(failedResult);
          this.emit("scenario_complete", { index: i, name: scenario.name, passed: false, summary: failedResult.summary });
          if (stopOnFirstFailure) {
            aborted = true;
            abortReason = `stopOnFirstFailure: scenario "${scenario.name}" crashed; skipping remaining ${scenarios.length - i - 1} scenarios.`;
            this.emit("reasoning", { text: abortReason });
            break;
          }
        }
      }
    } finally {
    }
    const report = {
      url,
      scenarios: results,
      totalDuration: Date.now() - startTime,
      passedCount: results.filter((r) => r.passed).length,
      failedCount: results.filter((r) => !r.passed).length,
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      ...aborted ? { aborted: true, abortReason } : {}
    };
    this.currentRun = null;
    this.emit("report", report);
    return report;
  }
  /** Close the browser.
   *  @param opts.keepBrowserOpen — When true, leave the browser window open after the test. */
  async close(opts) {
    try {
      await this.browser.close({ keepBrowserOpen: opts?.keepBrowserOpen });
    } catch {
    }
  }
  /**
   * Probe the target URL before launching Chrome. A hung/wedged dev server
   * would otherwise manifest as a 3-minute browser.navigate() hang followed
   * by an opaque "MCP client not connected" error. Any HTTP response (even
   * 4xx/5xx) is treated as "reachable" — we only fail on connection refused,
   * DNS failure, or timeout.
   */
  async preflightUrl(url, timeoutMs = 8e3) {
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return;
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return;
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    const t0 = Date.now();
    try {
      let res = await fetch(url, { method: "HEAD", signal: ac.signal, redirect: "manual" });
      if (res.status === 405 || res.status === 501) {
        res = await fetch(url, { method: "GET", signal: ac.signal, redirect: "manual" });
      }
      console.error(JSON.stringify({ event: "agent.preflight.ok", url, status: res.status, durationMs: Date.now() - t0, ts: (/* @__PURE__ */ new Date()).toISOString() }));
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      const aborted = ac.signal.aborted;
      console.error(JSON.stringify({ event: "agent.preflight.fail", url, aborted, error: msg, durationMs: Date.now() - t0, ts: (/* @__PURE__ */ new Date()).toISOString() }));
      if (aborted) {
        throw new Error(`Target URL ${url} did not respond within ${timeoutMs}ms. The server may be wedged, still starting, or unreachable. Restart the dev server and try again.`);
      }
      throw new Error(`Target URL ${url} is unreachable: ${msg}. Check that the server is running.`);
    } finally {
      clearTimeout(timer);
    }
  }
  /* ── Continuous page discovery ── */
  normalizeUrl(url) {
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname}`.replace(/\/$/, "");
    } catch {
      return url;
    }
  }
  shouldSkipUrl(url) {
    return SKIP_URL_PATTERNS.some((p) => p.test(url));
  }
  queueDiscoverPage(url) {
    const normalized = this.normalizeUrl(url);
    if (this.discoveredUrls.has(normalized)) return;
    if (this.discoveredUrls.size >= MAX_DISCOVERED_PAGES) return;
    if (this.shouldSkipUrl(url)) return;
    this.discoveredUrls.add(normalized);
    this.pendingDiscoveryUrls.push(normalized);
  }
  async flushDiscovery() {
    if (this.browserBusy || this.pendingDiscoveryUrls.length === 0) return;
    if (this.activeDiscoveries >= MAX_CONCURRENT_DISCOVERIES) return;
    const urls = this.pendingDiscoveryUrls.splice(0);
    for (const normalized of urls) {
      try {
        const snapshotText = await this.browser.snapshot();
        const screenshotData = await this.browser.screenshot();
        this.emit("page_discovered", { url: normalized, title: "", screenshot: screenshotData });
        this.activeDiscoveries++;
        this.generateDiscoveryCases(normalized, snapshotText, screenshotData).catch(() => {
        }).finally(() => {
          this.activeDiscoveries--;
        });
        break;
      } catch {
      }
    }
  }
  async generateDiscoveryCases(url, snapshotText, screenshot) {
    const prompt = `Analyze this page and generate test cases.

URL: ${url}

Accessibility Tree:
${snapshotText.slice(0, 4e3)}`;
    let fullText = "";
    if (this.provider === "gemini" && this.gemini) {
      const parts = [];
      if (screenshot) parts.push({ inlineData: { mimeType: "image/jpeg", data: screenshot } });
      parts.push({ text: prompt });
      const response = await this.gemini.models.generateContentStream({
        model: this.model,
        contents: [{ role: "user", parts }],
        config: { systemInstruction: DISCOVERY_SYSTEM_PROMPT }
      });
      for await (const chunk of response) {
        const text = chunk.text || "";
        if (text) {
          fullText += text;
          this.emit("discovered_cases_chunk", { url, text: fullText });
        }
      }
    } else if (this.anthropic) {
      const content = [];
      if (screenshot) content.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: screenshot } });
      content.push({ type: "text", text: prompt });
      const stream = this.anthropic.messages.stream({
        model: this.model,
        max_tokens: 1024,
        system: DISCOVERY_SYSTEM_PROMPT,
        messages: [{ role: "user", content }]
      });
      for await (const event of stream) {
        if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
          fullText += event.delta.text;
          this.emit("discovered_cases_chunk", { url, text: fullText });
        }
      }
    }
    this.emit("discovered_cases_complete", { url, cases: fullText });
  }
  parseScenarios(text) {
    const scenarioRegex = /(?:#?\s*(?:Scenario|Test|Case))\s*\d*[:.]\s*/gi;
    const parts = text.split(scenarioRegex).filter((s) => s.trim());
    if (parts.length > 1) {
      const names = text.match(scenarioRegex) || [];
      return parts.map((steps, i) => ({
        name: (names[i] || `Case ${i + 1}`).replace(/^#\s*/, "").replace(/[:.]\s*$/, "").trim(),
        steps: steps.trim()
      }));
    }
    return [{ name: "Test Scenario", steps: text.trim() }];
  }
  async runScenario(baseUrl, scenarioName, scenarioSteps, isFirstScenario, previousSummaries, browserReused, passCriteria, variables) {
    const startTime = Date.now();
    const steps = [];
    const assertions = [];
    let stepCounter = 0;
    let completed = false;
    let scenarioSummary = "";
    let scenarioPassed = true;
    const initialSnapshot = await this.browser.snapshot();
    const initialScreenshot = await this.browser.screenshot();
    if (initialScreenshot) {
      console.error(JSON.stringify({ event: "agent.screenshot.emit", size: initialScreenshot.length, ts: (/* @__PURE__ */ new Date()).toISOString() }));
      this.emit("screenshot", { base64: initialScreenshot });
    }
    let contextInfo = "";
    if (!isFirstScenario && previousSummaries.length > 0) {
      contextInfo = `

Previous Scenarios (browser state carries over):
${previousSummaries.map((s, i) => `${i + 1}. ${s}`).join("\n")}`;
    } else {
      contextInfo = `
Navigated to: ${baseUrl}`;
    }
    const emailInfo = this.tempEmail ? `
Active disposable email: ${this.tempEmail.address}` : "";
    const passCriteriaSection = passCriteria ? `

## Pass Criteria (MANDATORY)
The test MUST verify ALL of the following conditions. Mark the scenario as FAILED if any condition is not met:
${passCriteria}` : "";
    const variablesSection = variables && Object.keys(variables).length > 0 ? `

## Test Variables
The following variables were substituted into the test plan:
${Object.entries(variables).map(([k, v]) => `- {{${k}}} = "${v}"`).join("\n")}` : "";
    const userPrompt = `${contextInfo}${emailInfo}

Current page accessibility tree:
${initialSnapshot}

---
Execute this test scenario:
**${scenarioName}**
${scenarioSteps}${passCriteriaSection}${variablesSection}

IMPORTANT: Use snapshot refs (e.g. ref="e5") for reliable element targeting. Call snapshot before each interaction to get fresh refs.
If login/signup needs email, use create_temp_email first.

MANDATORY assertion coverage: every bullet above that starts with "Verify", "Check", "Assert", "Confirm", or "Ensure" requires exactly one corresponding assert tool call before you call complete_scenario. Do not silently skip any. If a bullet is impossible to verify (e.g. the element is missing), call assert with passed=false and explain what was missing as evidence. Re-read the bullets before completing to confirm coverage.

Analyze the page, act, make assertions, call complete_scenario when done.`;
    const messages = this.provider === "gemini" ? [{ role: "user", parts: [
      ...initialScreenshot ? [{ inlineData: { mimeType: "image/jpeg", data: initialScreenshot } }] : [],
      { text: userPrompt }
    ] }] : [{ role: "user", content: [
      ...initialScreenshot ? [{ type: "image", source: { type: "base64", media_type: "image/jpeg", data: initialScreenshot } }] : [],
      { type: "text", text: userPrompt }
    ] }];
    while (!completed && stepCounter < MAX_STEPS_PER_SCENARIO) {
      let toolCalls = [];
      for (let attempt = 0; attempt < 4; attempt++) {
        try {
          if (this.provider === "gemini" && this.gemini) {
            const response = await this.gemini.models.generateContent({
              model: this.model,
              contents: messages,
              config: { tools: [{ functionDeclarations: GEMINI_FUNCTION_DECLARATIONS }], systemInstruction: SYSTEM_PROMPT }
            });
            const candidate = response?.candidates?.[0];
            if (!candidate?.content?.parts) break;
            const parts = candidate.content.parts;
            messages.push({ role: "model", parts });
            for (const p of parts) {
              if (p.text?.trim()) this.emit("reasoning", { text: p.text });
            }
            toolCalls = parts.filter((p) => p.functionCall).map((p) => ({
              id: `gemini_${Date.now()}_${Math.random()}`,
              name: p.functionCall.name,
              args: p.functionCall.args || {}
            }));
          } else if (this.anthropic) {
            const response = await this.anthropic.messages.create({
              model: this.model,
              max_tokens: 4096,
              system: SYSTEM_PROMPT,
              tools: TOOLS,
              messages
            });
            const content = response.content;
            for (const b of content) {
              if (b.type === "text" && b.text.trim()) this.emit("reasoning", { text: b.text });
            }
            messages.push({ role: "assistant", content });
            toolCalls = content.filter((b) => b.type === "tool_use").map((b) => ({
              id: b.id,
              name: b.name,
              args: b.input
            }));
            if (toolCalls.length === 0 && response.stop_reason === "end_turn") {
              completed = true;
            }
          }
          break;
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          const isRetryable = /529|429|503|overloaded|rate/i.test(msg);
          if (isRetryable && attempt < 3) {
            const delay = (attempt + 1) * 5e3;
            this.emit("reasoning", { text: `API busy (attempt ${attempt + 1}/4), retrying in ${delay / 1e3}s...` });
            await new Promise((r) => setTimeout(r, delay));
            continue;
          }
          const isFatal = /tool_use|tool_result|invalid_request/i.test(msg);
          if (isFatal) {
            this.emit("reasoning", { text: `API error, ending scenario: ${msg.slice(0, 200)}` });
            scenarioPassed = false;
            scenarioSummary = `API error: ${msg.slice(0, 200)}`;
            completed = true;
            break;
          }
          throw err;
        }
      }
      if (toolCalls.length === 0) break;
      const toolResults = [];
      for (const toolCall of toolCalls) {
        this.browserBusy = true;
        const toolInput = toolCall.args;
        stepCounter++;
        let result = "";
        let stepAction = toolCall.name;
        let stepDescription = "";
        let stepStatus = "completed";
        this.emit("step", { id: stepCounter, action: toolCall.name, description: `Executing ${toolCall.name}...`, status: "running", timestamp: Date.now() });
        try {
          switch (toolCall.name) {
            case "navigate": {
              let navUrl = toolInput.url || "";
              if (navUrl.startsWith("/")) {
                const urlObj = new URL(baseUrl.startsWith("http") ? baseUrl : `https://${baseUrl}`);
                navUrl = `${urlObj.origin}${navUrl}`;
              }
              result = await this.browser.navigate(navUrl);
              stepDescription = `Navigate to ${navUrl}`;
              this.queueDiscoverPage(navUrl);
              break;
            }
            case "snapshot": {
              result = await this.browser.snapshot();
              stepDescription = "Get page snapshot (accessibility tree)";
              stepAction = "inspect";
              break;
            }
            case "click": {
              const element = toolInput.element;
              const ref = toolInput.ref;
              result = await this.browser.click(element, ref);
              stepDescription = `Click "${element}"${ref ? ` [ref=${ref}]` : ""}`;
              break;
            }
            case "type_text": {
              const element = toolInput.element;
              const text = toolInput.text;
              const ref = toolInput.ref;
              result = await this.browser.type(element, text, ref);
              stepDescription = `Type "${text}" into "${element}"`;
              break;
            }
            case "select_option": {
              const element = toolInput.element;
              const values = toolInput.values || [toolInput.value];
              result = await this.browser.selectOption(element, values);
              stepDescription = `Select "${values.join(", ")}" in "${element}"`;
              break;
            }
            case "scroll": {
              const x = toolInput.x || 0;
              const y = toolInput.y || 400;
              result = await this.browser.scroll(x, y);
              stepDescription = `Scroll ${y > 0 ? "down" : "up"} by ${Math.abs(y)}px`;
              break;
            }
            case "press_key": {
              const key = toolInput.key;
              result = await this.browser.pressKey(key);
              stepDescription = `Press ${key}`;
              break;
            }
            case "wait": {
              if (toolInput.text) {
                result = await this.browser.waitForText(toolInput.text, toolInput.ms || 1e4);
                stepDescription = `Wait for text "${toolInput.text}"`;
              } else {
                const ms = Math.min(toolInput.ms || 1e3, 1e4);
                await new Promise((r) => setTimeout(r, ms));
                result = `Waited ${ms}ms`;
                stepDescription = `Wait ${ms}ms`;
              }
              break;
            }
            case "screenshot": {
              const data = await this.browser.screenshot();
              if (data) {
                this.emit("screenshot", { base64: data });
                result = "Screenshot taken and sent to client.";
              } else {
                result = "Screenshot failed.";
              }
              stepDescription = "Take screenshot";
              stepAction = "inspect";
              break;
            }
            case "evaluate": {
              const expr = toolInput.expression;
              result = await this.browser.evaluate(expr);
              stepDescription = `Evaluate JS: ${expr.slice(0, 80)}`;
              stepAction = "inspect";
              break;
            }
            case "create_temp_email": {
              this.tempEmail = await DisposableEmail.create();
              result = `Created disposable email: ${this.tempEmail.address}
Use this EXACT email in signup forms.`;
              stepDescription = `Created temp email: ${this.tempEmail.address}`;
              stepAction = "email";
              this.emit("reasoning", { text: `Disposable email created: ${this.tempEmail.address}` });
              break;
            }
            case "wait_for_verification_code": {
              if (!this.tempEmail) {
                result = "Error: Call create_temp_email first.";
                stepStatus = "failed";
                stepDescription = "No temp email";
                break;
              }
              const timeout = Math.min((toolInput.timeout_seconds || 60) * 1e3, 12e4);
              stepDescription = `Waiting for code at ${this.tempEmail.address}...`;
              this.emit("step", { id: stepCounter, action: "email", description: stepDescription, status: "running", timestamp: Date.now() });
              const cr = await this.tempEmail.waitForVerificationCode(timeout, 3e3);
              if (cr?.code) {
                result = `Verification code received: ${cr.code}
From: ${cr.from}
Subject: ${cr.subject}`;
                stepDescription = `Received code: ${cr.code}`;
                stepAction = "email";
              } else if (cr) {
                result = `Email received but no code pattern found.
From: ${cr.from}
Subject: ${cr.subject}
Body: ${cr.body}`;
                stepDescription = "Email received, manual extraction needed";
                stepAction = "email";
              } else {
                result = `No email within ${timeout / 1e3}s.`;
                stepStatus = "failed";
                stepDescription = "Verification email timeout";
                stepAction = "email";
              }
              break;
            }
            case "check_email_inbox": {
              if (!this.tempEmail) {
                result = "Error: Call create_temp_email first.";
                stepStatus = "failed";
                stepDescription = "No temp email";
                break;
              }
              const msgs = await this.tempEmail.getMessages();
              if (msgs.length === 0) {
                result = `Inbox empty for ${this.tempEmail.address}.`;
              } else {
                const latest = msgs[msgs.length - 1];
                const body = (latest.body_text || latest.body_html || "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
                result = `${msgs.length} email(s). Latest from: ${latest.from} | Subject: ${latest.subject}
Body: ${body.slice(0, 5e3)}`;
              }
              stepDescription = `Check inbox (${msgs.length} emails)`;
              stepAction = "email";
              break;
            }
            case "assert": {
              const desc = toolInput.description;
              const passed = toolInput.passed;
              const evidence = toolInput.evidence;
              assertions.push({ description: desc, passed, evidence });
              result = `Assertion ${passed ? "PASSED" : "FAILED"}: ${desc} \u2014 ${evidence}`;
              stepDescription = `Assert: ${desc}`;
              stepAction = passed ? "assert_pass" : "assert_fail";
              if (!passed) scenarioPassed = false;
              this.emit("assertion", { description: desc, passed, evidence });
              break;
            }
            case "complete_scenario": {
              scenarioSummary = toolInput.summary;
              scenarioPassed = toolInput.passed;
              completed = true;
              result = "Scenario complete";
              stepDescription = "Scenario complete";
              stepAction = "complete";
              break;
            }
            case "suggest_improvement": {
              const title = toolInput.title;
              const severity = toolInput.severity;
              const desc = toolInput.description;
              const suggestion = toolInput.suggestion;
              this.emit("improvement_suggestion", { title, severity, description: desc, suggestion });
              result = `Improvement logged: ${title}`;
              stepDescription = `Issue: ${title}`;
              stepAction = "suggestion";
              break;
            }
            case "http_request": {
              const reqUrl = toolInput.url;
              const method = (toolInput.method || "GET").toUpperCase();
              const headers = toolInput.headers || {};
              const body = toolInput.body;
              try {
                const fetchOptions = {
                  method,
                  headers: { "Content-Type": "application/json", ...headers }
                };
                if (body && method !== "GET" && method !== "HEAD") {
                  fetchOptions.body = body;
                }
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 3e4);
                fetchOptions.signal = controller.signal;
                const resp = await fetch(reqUrl, fetchOptions);
                clearTimeout(timeoutId);
                const respText = await resp.text();
                const truncated = respText.length > 4e3 ? respText.slice(0, 4e3) + "\n...(truncated)" : respText;
                result = `HTTP ${resp.status} ${resp.statusText}

${truncated}`;
                stepDescription = `${method} ${reqUrl} \u2192 ${resp.status}`;
              } catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                result = `HTTP request failed: ${msg}`;
                stepStatus = "failed";
                stepDescription = `${method} ${reqUrl} failed`;
              }
              stepAction = "http";
              break;
            }
            case "wait_for_stable": {
              const timeoutSec = Math.min(toolInput.timeout_seconds || 30, 60);
              const stableSec = Math.min(toolInput.stable_seconds || 2, 10);
              stepDescription = `Wait for page to stabilize (${stableSec}s quiet, ${timeoutSec}s max)`;
              this.emit("step", { id: stepCounter, action: "wait", description: stepDescription, status: "running", timestamp: Date.now() });
              try {
                await this.browser.evaluate(`
                  window.__assrt_mutations = 0;
                  window.__assrt_observer = new MutationObserver((mutations) => {
                    window.__assrt_mutations += mutations.length;
                  });
                  window.__assrt_observer.observe(document.body, {
                    childList: true, subtree: true, characterData: true
                  });
                `);
                const startMs = Date.now();
                const timeoutMs = timeoutSec * 1e3;
                const stableMs = stableSec * 1e3;
                let lastMutationCount = -1;
                let stableSince = Date.now();
                while (Date.now() - startMs < timeoutMs) {
                  await new Promise((r) => setTimeout(r, 500));
                  const countStr = await this.browser.evaluate("window.__assrt_mutations");
                  const count = parseInt(countStr, 10) || 0;
                  if (count !== lastMutationCount) {
                    lastMutationCount = count;
                    stableSince = Date.now();
                  } else if (Date.now() - stableSince >= stableMs) {
                    break;
                  }
                }
                await this.browser.evaluate(`
                  if (window.__assrt_observer) { window.__assrt_observer.disconnect(); }
                  delete window.__assrt_mutations;
                  delete window.__assrt_observer;
                `);
                const elapsed = ((Date.now() - startMs) / 1e3).toFixed(1);
                const stable = Date.now() - stableSince >= stableMs;
                result = stable ? `Page stabilized after ${elapsed}s (${lastMutationCount} total mutations)` : `Timed out after ${timeoutSec}s (page still changing, ${lastMutationCount} mutations)`;
                stepDescription = stable ? `Page stable after ${elapsed}s` : `Stability timeout after ${timeoutSec}s`;
              } catch (err) {
                const msg = err instanceof Error ? err.message : String(err);
                result = `wait_for_stable failed: ${msg}`;
                stepStatus = "failed";
                stepDescription = "wait_for_stable failed";
              }
              stepAction = "wait";
              break;
            }
            default:
              result = `Unknown: ${toolCall.name}`;
              stepDescription = `Unknown: ${toolCall.name}`;
          }
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          let snapshotText = "";
          try {
            snapshotText = await this.browser.snapshot();
          } catch {
          }
          result = `Error: ${msg}

The action "${toolCall.name}" failed. Current page accessibility tree:
${snapshotText.slice(0, 2e3)}

Please call snapshot and try a different approach.`;
          stepStatus = "failed";
          stepDescription = `${toolCall.name} failed: ${msg.slice(0, 100)}`;
        }
        let screenshotData = null;
        if (!["snapshot", "wait", "wait_for_stable", "assert", "complete_scenario", "create_temp_email", "wait_for_verification_code", "check_email_inbox", "screenshot", "evaluate", "http_request"].includes(toolCall.name)) {
          try {
            screenshotData = await this.browser.screenshot();
            if (screenshotData) {
              console.error(JSON.stringify({ event: "agent.screenshot.emit", size: screenshotData.length, ts: (/* @__PURE__ */ new Date()).toISOString() }));
              this.emit("screenshot", { base64: screenshotData });
            }
          } catch {
          }
        }
        steps.push({ id: stepCounter, action: stepAction, description: stepDescription, status: stepStatus, timestamp: Date.now() });
        this.emit("step", { id: stepCounter, action: stepAction, description: stepDescription, status: stepStatus, timestamp: Date.now() });
        if (this.provider === "gemini") {
          toolResults.push({ functionResponse: { name: toolCall.name, response: { result } } });
        } else {
          const toolResultContent = [{ type: "text", text: result }];
          if (screenshotData) {
            toolResultContent.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: screenshotData } });
          }
          toolResults.push({ type: "tool_result", tool_use_id: toolCall.id, content: toolResultContent });
        }
        this.browserBusy = false;
      }
      await this.flushDiscovery().catch(() => {
      });
      if (this.provider === "gemini") {
        messages.push({ role: "function", parts: toolResults });
        const latestScreenshot = await this.browser.screenshot();
        const latestSnapshot = await this.browser.snapshot();
        messages.push({ role: "user", parts: [
          ...latestScreenshot ? [{ inlineData: { mimeType: "image/jpeg", data: latestScreenshot } }] : [],
          { text: `Current page accessibility tree:
${latestSnapshot.slice(0, 3e3)}

Continue with the test scenario.` }
        ] });
      } else {
        messages.push({ role: "user", content: toolResults });
      }
      if (messages.length > MAX_CONVERSATION_TURNS * 2 + 2) {
        const initial = messages.slice(0, 1);
        let cutIdx = messages.length - MAX_CONVERSATION_TURNS * 2;
        if (cutIdx < 1) cutIdx = 1;
        while (cutIdx < messages.length - 2) {
          const msg = messages[cutIdx];
          const role = msg.role;
          if (role === "assistant" || role === "model") break;
          cutIdx++;
        }
        const recent = messages.slice(cutIdx);
        messages.length = 0;
        messages.push(...initial, ...recent);
      }
    }
    if (!completed) scenarioSummary = `Reached max steps (${MAX_STEPS_PER_SCENARIO})`;
    const verifyBulletRegex = /^[\s\-*\d.()]*(?:Verify|Check|Assert|Confirm|Ensure)\b[^\n]*/gim;
    const verifyBullets = (scenarioSteps.match(verifyBulletRegex) || []).map((s) => s.replace(/^[\s\-*\d.()]+/, "").trim()).filter((s) => s.length > 0);
    const assertionDescriptions = assertions.map((a) => a.description.toLowerCase());
    const normalize = (s) => s.toLowerCase().replace(/[^a-z0-9 ]+/g, " ").split(/\s+/).filter((w) => w.length > 3);
    const droppedAssertions = [];
    for (const bullet of verifyBullets) {
      const bulletKeywords = normalize(bullet);
      if (bulletKeywords.length === 0) continue;
      const covered = assertionDescriptions.some((desc) => {
        const matched = bulletKeywords.filter((kw) => desc.includes(kw)).length;
        return matched >= Math.min(2, bulletKeywords.length);
      });
      if (!covered) droppedAssertions.push(bullet);
    }
    if (droppedAssertions.length > 0) {
      scenarioPassed = false;
      const dropMsg = `Agent skipped ${droppedAssertions.length} mandatory verify bullet${droppedAssertions.length === 1 ? "" : "s"} (no matching assert call): ${droppedAssertions.slice(0, 3).join(" | ")}${droppedAssertions.length > 3 ? " \u2026" : ""}`;
      scenarioSummary = scenarioSummary ? `${scenarioSummary} | ${dropMsg}` : dropMsg;
      console.error(JSON.stringify({ event: "agent.coverage.dropped", scenario: scenarioName, count: droppedAssertions.length, bullets: droppedAssertions }));
    }
    return {
      name: scenarioName,
      passed: scenarioPassed,
      steps,
      assertions,
      summary: scenarioSummary,
      duration: Date.now() - startTime,
      expectedAssertions: verifyBullets.length,
      ...droppedAssertions.length > 0 ? { droppedAssertions } : {}
    };
  }
};

// src/core/telemetry.ts
import { createHash } from "crypto";
import { hostname, platform, arch, userInfo } from "os";
import { readFileSync } from "fs";
import { dirname, join as join2 } from "path";
import { fileURLToPath } from "url";
import { readFileSync as readSync, writeFileSync as writeSync } from "fs";
import { join as joinPath } from "path";
import { tmpdir as getTmpdir } from "os";
var POSTHOG_KEY = "phc_mS27BrT7FC5m3BiVjDj9T4iOpVY9Oh1PB3g3bHsEiQv";
var POSTHOG_HOST = "https://us.i.posthog.com";
var cachedVersion = null;
function getVersion() {
  if (cachedVersion) return cachedVersion;
  try {
    let dir = dirname(fileURLToPath(import.meta.url));
    for (let i = 0; i < 6; i++) {
      try {
        const pkg = JSON.parse(readFileSync(join2(dir, "package.json"), "utf-8"));
        if (typeof pkg.version === "string" && (pkg.name === "@assrt-ai/assrt" || pkg.name === "assrt-sdk")) {
          cachedVersion = pkg.version;
          return cachedVersion;
        }
      } catch {
      }
      const parent = dirname(dir);
      if (parent === dir) break;
      dir = parent;
    }
  } catch {
  }
  cachedVersion = "unknown";
  return cachedVersion;
}
function isEnabled() {
  if (process.env.DO_NOT_TRACK === "1") return false;
  if (process.env.ASSRT_TELEMETRY === "0") return false;
  return true;
}
function getMachineId() {
  const raw = `${hostname()}:${userInfo().username}:assrt`;
  return createHash("sha256").update(raw).digest("hex").slice(0, 16);
}
function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return "unknown";
  }
}
var posthogClient = null;
async function getClient() {
  if (posthogClient) return posthogClient;
  try {
    const { PostHog } = await import("posthog-node");
    posthogClient = new PostHog(POSTHOG_KEY, {
      host: POSTHOG_HOST,
      flushAt: 1,
      flushInterval: 0,
      // Custom fetch that silently swallows TLS/network errors.
      // Returns a fake 200 so PostHog SDK doesn't log errors to stderr.
      fetch: async (url, options) => {
        try {
          return await globalThis.fetch(url, options);
        } catch {
          return new Response("{}", { status: 200, headers: { "content-type": "application/json" } });
        }
      }
    });
    posthogClient.on("error", () => {
    });
    return posthogClient;
  } catch {
    return null;
  }
}
var DEDUP_FILE = joinPath(getTmpdir(), "assrt-telemetry-dedup.json");
function shouldSend(event) {
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const machineId = getMachineId();
  const key = `${machineId}:${event}`;
  try {
    const data = JSON.parse(readSync(DEDUP_FILE, "utf-8"));
    if (data[key] === today) return false;
    data[key] = today;
    writeSync(DEDUP_FILE, JSON.stringify(data));
    return true;
  } catch {
    try {
      writeSync(DEDUP_FILE, JSON.stringify({ [key]: today }));
    } catch {
    }
    return true;
  }
}
async function trackEvent(event, props = {}, options) {
  if (!isEnabled()) return;
  if (options?.dedupeDaily && !shouldSend(event)) return;
  try {
    const client = await getClient();
    if (!client) return;
    const { url, ...rest } = props;
    client.capture({
      distinctId: getMachineId(),
      event,
      properties: {
        ...rest,
        domain: url ? getDomain(url) : void 0,
        version: getVersion(),
        os: platform(),
        arch: arch(),
        node_version: process.version
      }
    });
  } catch {
  }
}
async function shutdownTelemetry() {
  if (posthogClient) {
    try {
      await posthogClient.shutdown();
    } catch {
    }
  }
}

export {
  getCredential,
  ExtensionTokenRequired,
  McpBrowserManager,
  TestAgent,
  trackEvent,
  shutdownTelemetry
};
