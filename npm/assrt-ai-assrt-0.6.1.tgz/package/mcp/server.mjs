#!/usr/bin/env node
import {
  ExtensionTokenRequired,
  McpBrowserManager,
  TestAgent,
  getCredential,
  shutdownTelemetry,
  trackEvent
} from "../chunk-R3P2EBAN.mjs";

// src/mcp/server.ts
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { mkdirSync as mkdirSync3, writeFileSync as writeFileSync3, readFileSync as readFileSync3, readdirSync } from "fs";
import { join as join3, basename } from "path";
import { tmpdir } from "os";
import { execSync } from "child_process";

// src/core/scenario-store.ts
import { mkdirSync, readFileSync, writeFileSync, existsSync } from "fs";
import { join } from "path";
import { homedir } from "os";
var CENTRAL_API_URL = process.env.ASSRT_API_URL || "https://app.assrt.ai";
var LOCAL_DIR = join(homedir(), ".assrt", "scenarios");
function ensureLocalDir() {
  try {
    mkdirSync(LOCAL_DIR, { recursive: true });
  } catch {
  }
}
function localPath(scenarioId) {
  return join(LOCAL_DIR, `${scenarioId}.json`);
}
function writeLocal(scenario) {
  ensureLocalDir();
  try {
    writeFileSync(localPath(scenario.id), JSON.stringify(scenario, null, 2));
  } catch (err) {
    console.error("[scenario-store] Failed to write local cache:", err.message);
  }
}
function readLocal(scenarioId) {
  const path = localPath(scenarioId);
  if (!existsSync(path)) return null;
  try {
    return JSON.parse(readFileSync(path, "utf-8"));
  } catch {
    return null;
  }
}
async function fetchScenario(scenarioId) {
  try {
    const res = await fetch(`${CENTRAL_API_URL}/api/public/scenarios/${scenarioId}`, {
      method: "GET",
      headers: { "Accept": "application/json" },
      signal: AbortSignal.timeout(1e4)
    });
    if (!res.ok) {
      if (res.status === 404) return null;
      throw new Error(`HTTP ${res.status}`);
    }
    const data = await res.json();
    const scenario = {
      id: data.id,
      plan: data.plan,
      name: data.name,
      url: data.url,
      passCriteria: data.passCriteria,
      variables: data.variables,
      tags: data.tags,
      createdAt: data.createdAt,
      updatedAt: data.updatedAt
    };
    writeLocal(scenario);
    return scenario;
  } catch (err) {
    console.error("[scenario-store] Central fetch failed, trying local cache:", err.message);
    return readLocal(scenarioId);
  }
}
async function saveScenario(data) {
  try {
    const res = await fetch(`${CENTRAL_API_URL}/api/public/scenarios`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
      signal: AbortSignal.timeout(1e4)
    });
    if (!res.ok) {
      const errBody = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status}: ${errBody}`);
    }
    const result = await res.json();
    writeLocal({ id: result.id, plan: data.plan, name: data.name, url: data.url, passCriteria: data.passCriteria, variables: data.variables, tags: data.tags, createdAt: result.createdAt });
    return result.id;
  } catch (err) {
    console.error("[scenario-store] Central save failed:", err.message);
    const crypto = await import("crypto");
    const localId = `local-${crypto.randomUUID()}`;
    writeLocal({ id: localId, plan: data.plan, name: data.name, url: data.url, passCriteria: data.passCriteria, variables: data.variables, tags: data.tags });
    return localId;
  }
}
async function updateScenario(scenarioId, data) {
  try {
    const res = await fetch(`${CENTRAL_API_URL}/api/public/scenarios/${scenarioId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
      signal: AbortSignal.timeout(1e4)
    });
    if (!res.ok) return false;
    const existing = readLocal(scenarioId);
    if (existing) {
      if (data.plan) existing.plan = data.plan;
      if (data.name) existing.name = data.name;
      if (data.url) existing.url = data.url;
      existing.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
      writeLocal(existing);
    }
    return true;
  } catch (err) {
    console.error("[scenario-store] Central update failed:", err.message);
    return false;
  }
}
async function saveScenarioRun(scenarioId, data) {
  try {
    const res = await fetch(`${CENTRAL_API_URL}/api/public/scenarios/${scenarioId}/runs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
      signal: AbortSignal.timeout(15e3)
    });
    if (res.ok) {
      const result = await res.json();
      return result.run?.id || null;
    }
    return null;
  } catch (err) {
    console.error("[scenario-store] Failed to save run:", err.message);
    return null;
  }
}
async function uploadArtifacts(scenarioId, runId, files) {
  const { readFileSync: readFileSync4, existsSync: existsSync3 } = await import("fs");
  const formData = new FormData();
  for (const f of files) {
    if (!existsSync3(f.path)) continue;
    try {
      const buffer = readFileSync4(f.path);
      const blob = new Blob([buffer], { type: f.type });
      formData.append(f.name, blob, f.name);
    } catch (err) {
      console.error(`[scenario-store] Failed to read artifact ${f.name}:`, err.message);
    }
  }
  try {
    const res = await fetch(
      `${CENTRAL_API_URL}/api/public/scenarios/${scenarioId}/runs/${runId}/artifacts`,
      {
        method: "POST",
        body: formData,
        signal: AbortSignal.timeout(12e4)
        // 2 min for large videos
      }
    );
    if (res.ok) {
      console.error(`[scenario-store] Uploaded ${files.length} artifact(s) for run ${runId.slice(0, 8)}...`);
    } else {
      console.error(`[scenario-store] Artifact upload failed: HTTP ${res.status}`);
    }
  } catch (err) {
    console.error("[scenario-store] Artifact upload failed:", err.message);
  }
}
function buildCloudUrls(scenarioId, runId, artifactNames) {
  const base = `${CENTRAL_API_URL}/api/public/scenarios/${scenarioId}/runs/${runId}/artifacts`;
  const urls = {
    page: `${CENTRAL_API_URL}/s/${scenarioId}`
  };
  if (artifactNames.video) urls.video = `${base}?file=${artifactNames.video}`;
  if (artifactNames.log) urls.log = `${base}?file=${artifactNames.log}`;
  if (artifactNames.screenshots?.length) {
    urls.screenshots = artifactNames.screenshots.map((s) => `${base}?file=${s}`);
  }
  return urls;
}

// src/core/scenario-files.ts
import { mkdirSync as mkdirSync2, writeFileSync as writeFileSync2, readFileSync as readFileSync2, existsSync as existsSync2, watch } from "fs";
import { join as join2 } from "path";
var ASSRT_DIR = "/tmp/assrt";
var SCENARIO_FILE = join2(ASSRT_DIR, "scenario.md");
var SCENARIO_META = join2(ASSRT_DIR, "scenario.json");
var RESULTS_DIR = join2(ASSRT_DIR, "results");
var LATEST_RESULTS = join2(RESULTS_DIR, "latest.json");
var activeWatcher = null;
var syncDebounceTimer = null;
var lastWrittenContent = null;
function ensureDirs() {
  mkdirSync2(ASSRT_DIR, { recursive: true });
  mkdirSync2(RESULTS_DIR, { recursive: true });
}
function writeScenarioFile(plan, meta) {
  ensureDirs();
  lastWrittenContent = plan;
  writeFileSync2(SCENARIO_FILE, plan, "utf-8");
  writeFileSync2(SCENARIO_META, JSON.stringify(meta, null, 2), "utf-8");
  startWatching(meta.id);
}
function readScenarioFile() {
  if (!existsSync2(SCENARIO_FILE)) return null;
  try {
    return readFileSync2(SCENARIO_FILE, "utf-8");
  } catch {
    return null;
  }
}
function readScenarioMeta() {
  if (!existsSync2(SCENARIO_META)) return null;
  try {
    return JSON.parse(readFileSync2(SCENARIO_META, "utf-8"));
  } catch {
    return null;
  }
}
function writeResultsFile(runId, results) {
  ensureDirs();
  const json = JSON.stringify(results, null, 2);
  writeFileSync2(LATEST_RESULTS, json, "utf-8");
  const runPath = join2(RESULTS_DIR, `${runId}.json`);
  writeFileSync2(runPath, json, "utf-8");
  return { latestPath: LATEST_RESULTS, runPath };
}
function startWatching(scenarioId) {
  stopWatching();
  if (scenarioId.startsWith("local-")) return;
  try {
    activeWatcher = watch(SCENARIO_FILE, { persistent: false }, (_event) => {
      if (syncDebounceTimer) clearTimeout(syncDebounceTimer);
      syncDebounceTimer = setTimeout(() => {
        syncToFirestore(scenarioId);
      }, 1e3);
    });
    activeWatcher.on("error", (err) => {
      console.error("[scenario-files] Watcher error:", err.message);
    });
  } catch (err) {
    console.error("[scenario-files] Failed to start watcher:", err.message);
  }
}
function stopWatching() {
  if (syncDebounceTimer) {
    clearTimeout(syncDebounceTimer);
    syncDebounceTimer = null;
  }
  if (activeWatcher) {
    activeWatcher.close();
    activeWatcher = null;
  }
}
async function syncToFirestore(scenarioId) {
  try {
    const currentContent = readScenarioFile();
    if (!currentContent) return;
    if (currentContent === lastWrittenContent) return;
    lastWrittenContent = currentContent;
    const meta = readScenarioMeta();
    console.error(`[scenario-files] Detected edit, syncing scenario ${scenarioId.slice(0, 8)}... to Firestore`);
    const success = await updateScenario(scenarioId, {
      plan: currentContent,
      name: meta?.name,
      url: meta?.url
    });
    if (success) {
      if (meta) {
        meta.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
        writeFileSync2(SCENARIO_META, JSON.stringify(meta, null, 2), "utf-8");
      }
      console.error("[scenario-files] Sync complete");
    } else {
      console.error("[scenario-files] Sync failed (API returned false)");
    }
  } catch (err) {
    console.error("[scenario-files] Sync error:", err.message);
  }
}
var PATHS = {
  scenarioFile: SCENARIO_FILE,
  scenarioMeta: SCENARIO_META,
  resultsDir: RESULTS_DIR,
  latestResults: LATEST_RESULTS
};

// src/core/seed.ts
import { spawn } from "child_process";
var DEFAULT_TIMEOUTS = {
  cookies: 6e4,
  localstorage: 18e4,
  indexeddb: 3e5
};
var PY_MODULES = {
  cookies: "ai_browser_profile.cookies",
  localstorage: "ai_browser_profile.localstorage",
  indexeddb: "ai_browser_profile.indexeddb"
};
var FILTER_FLAG = {
  cookies: "--domains",
  localstorage: "--origins",
  indexeddb: "--origins"
};
function resolvePython() {
  return process.env.ASSRT_ABP_PYTHON?.trim() || "python3";
}
async function seed(kind, opts) {
  const python = resolvePython();
  const cdpUrl = opts.cdpUrl.trim();
  if (!cdpUrl) {
    return {
      ok: false,
      kind,
      returncode: -1,
      stdout: "",
      stderr: "",
      error: "cdpUrl is required"
    };
  }
  const args = [
    "-m",
    PY_MODULES[kind],
    "copy",
    "--from",
    opts.source,
    "--to",
    cdpUrl
  ];
  if (opts.filter && opts.filter.trim()) {
    args.push(FILTER_FLAG[kind], opts.filter.trim());
  }
  if (opts.loadWait != null && (kind === "localstorage" || kind === "indexeddb")) {
    args.push("--load-wait", String(opts.loadWait));
  }
  if (opts.verbose) args.push("-v");
  const timeoutMs = opts.timeoutMs ?? DEFAULT_TIMEOUTS[kind];
  return new Promise((resolve) => {
    let stdout = "";
    let stderr = "";
    let settled = false;
    const child = spawn(python, args, {
      stdio: ["ignore", "pipe", "pipe"],
      env: process.env
    });
    const settle = (result) => {
      if (settled) return;
      settled = true;
      resolve(result);
    };
    const timer = setTimeout(() => {
      try {
        child.kill("SIGKILL");
      } catch {
      }
      settle({
        ok: false,
        kind,
        returncode: -1,
        stdout,
        stderr,
        error: `seed ${kind} timed out after ${timeoutMs}ms`
      });
    }, timeoutMs);
    child.stdout?.on("data", (d) => {
      stdout += d.toString("utf-8");
    });
    child.stderr?.on("data", (d) => {
      stderr += d.toString("utf-8");
    });
    child.on("error", (err) => {
      clearTimeout(timer);
      const msg = err.code === "ENOENT" ? `python interpreter not found: ${python}. Install ai-browser-profile (\`pip install ai-browser-profile\`) or set ASSRT_ABP_PYTHON to a python that has it.` : err.message;
      settle({
        ok: false,
        kind,
        returncode: -1,
        stdout,
        stderr,
        error: msg
      });
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      const returncode = code ?? -1;
      if (returncode !== 0 && /No module named 'ai_browser_profile'/.test(stderr)) {
        settle({
          ok: false,
          kind,
          returncode,
          stdout,
          stderr,
          error: `ai_browser_profile not installed in ${python}. Install it with \`${python} -m pip install ai-browser-profile\` or set ASSRT_ABP_PYTHON to a python that has it.`
        });
        return;
      }
      settle({
        ok: returncode === 0,
        kind,
        returncode,
        stdout,
        stderr
      });
    });
  });
}

// src/mcp/server.ts
var sharedBrowser = null;
async function anthropicFromCredential(credential) {
  if (credential.provider !== "anthropic") {
    throw new Error(
      `Expected Anthropic credential, got '${credential.provider}'. This is a bug in the provider-aware dispatch in assrt_plan/assrt_diagnose.`
    );
  }
  const Anthropic = (await import("@anthropic-ai/sdk")).default;
  return credential.type === "oauth" ? new Anthropic({ authToken: credential.token, defaultHeaders: { "anthropic-beta": "oauth-2025-04-20" } }) : new Anthropic({ apiKey: credential.token });
}
async function geminiFromCredential(credential) {
  if (credential.provider !== "gemini") {
    throw new Error(
      `Expected Gemini credential, got '${credential.provider}'. This is a bug in the provider-aware dispatch in assrt_plan/assrt_diagnose.`
    );
  }
  const { GoogleGenAI } = await import("@google/genai");
  return new GoogleGenAI({ apiKey: credential.token });
}
var DEFAULT_ANTHROPIC_PLAN_MODEL = "claude-haiku-4-5-20251001";
var DEFAULT_GEMINI_PLAN_MODEL = "gemini-flash-latest";
function defaultModelFor(provider) {
  return provider === "gemini" ? DEFAULT_GEMINI_PLAN_MODEL : DEFAULT_ANTHROPIC_PLAN_MODEL;
}
function generateVideoPlayerHtml(videoFilename, testUrl, passedCount, failedCount, durationSec) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Assrt Test Recording</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { background: #0a0a0f; color: #e5e7eb; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; display: flex; flex-direction: column; height: 100vh; padding: 8px; }
  .header { width: 100%; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; padding: 0 8px; flex-shrink: 0; }
  .brand { font-size: 20px; font-weight: 700; letter-spacing: -0.5px; }
  .brand span { color: #22c55e; }
  .meta { display: flex; gap: 16px; font-size: 13px; color: #9ca3af; }
  .meta .pass { color: #22c55e; font-weight: 600; }
  .meta .fail { color: #ef4444; font-weight: 600; }
  .video-wrap { width: 100%; flex: 1; min-height: 0; background: #111118; border-radius: 12px; overflow: hidden; border: 1px solid #1f1f2e; display: flex; flex-direction: column; }
  video { width: 100%; flex: 1; min-height: 0; object-fit: contain; display: block; }
  .controls { padding: 8px 16px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap; flex-shrink: 0; }
  .speed-group { display: flex; gap: 4px; }
  .speed-btn { background: #1a1a26; border: 1px solid #2a2a3a; color: #9ca3af; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 500; transition: all 0.15s; }
  .speed-btn:hover { background: #252536; color: #e5e7eb; }
  .speed-btn.active { background: #22c55e; color: #0a0a0f; border-color: #22c55e; font-weight: 700; }
  .hint { margin-left: auto; font-size: 12px; color: #6b7280; }
  kbd { background: #1a1a26; border: 1px solid #2a2a3a; border-radius: 4px; padding: 1px 6px; font-size: 11px; font-family: inherit; }
</style>
</head>
<body>
<div class="header">
  <div class="brand">assrt<span>.</span></div>
  <div class="meta">
    <span>${testUrl}</span>
    <span class="pass">${passedCount} passed</span>
    ${failedCount > 0 ? `<span class="fail">${failedCount} failed</span>` : ""}
    <span>${durationSec}s</span>
  </div>
</div>
<div class="video-wrap">
  <video id="v" controls autoplay muted>
    <source src="${videoFilename}" type="video/webm">
  </video>
  <div class="controls">
    <div class="speed-group">
      <button class="speed-btn" data-speed="1">1x</button>
      <button class="speed-btn" data-speed="2">2x</button>
      <button class="speed-btn" data-speed="3">3x</button>
      <button class="speed-btn active" data-speed="5">5x</button>
      <button class="speed-btn" data-speed="10">10x</button>
    </div>
    <div class="hint"><kbd>Space</kbd> play/pause &nbsp; <kbd>1</kbd><kbd>2</kbd><kbd>3</kbd><kbd>5</kbd> speed &nbsp; <kbd>\u2190</kbd><kbd>\u2192</kbd> seek 5s</div>
  </div>
</div>
<script>
const v = document.getElementById('v');
const btns = document.querySelectorAll('.speed-btn');
function setSpeed(s) {
  v.playbackRate = s;
  btns.forEach(b => b.classList.toggle('active', +b.dataset.speed === s));
}
v.addEventListener('loadeddata', () => setSpeed(5));
btns.forEach(b => b.addEventListener('click', () => setSpeed(+b.dataset.speed)));
document.addEventListener('keydown', e => {
  if (e.key === ' ') { e.preventDefault(); v.paused ? v.play() : v.pause(); }
  if (e.key === 'ArrowLeft') { v.currentTime = Math.max(0, v.currentTime - 5); }
  if (e.key === 'ArrowRight') { v.currentTime += 5; }
  const speedMap = { '1': 1, '2': 2, '3': 3, '5': 5, '0': 10 };
  if (speedMap[e.key]) setSpeed(speedMap[e.key]);
});
</script>
</body>
</html>`;
}
var videoServerPort = null;
var videoServerInstance = null;
async function ensureVideoServer() {
  if (videoServerPort && videoServerInstance) return videoServerPort;
  const http = await import("http");
  const fs = await import("fs");
  const pathMod = await import("path");
  const mime = { ".html": "text/html", ".webm": "video/webm", ".mp4": "video/mp4" };
  const srv = http.createServer((req, res) => {
    const url = new URL(req.url || "/", `http://${req.headers.host}`);
    const dir = url.searchParams.get("dir");
    if (url.pathname === "/player.html" && dir) {
      try {
        const playerPath = pathMod.join(dir, "player.html");
        const data = fs.readFileSync(playerPath, "utf-8");
        const videoFiles = fs.readdirSync(dir).filter((f) => f.endsWith(".webm"));
        const rewritten = videoFiles.length > 0 ? data.replace(
          `src="${videoFiles[0]}"`,
          `src="/video/${encodeURIComponent(videoFiles[0])}?dir=${encodeURIComponent(dir)}"`
        ) : data;
        res.writeHead(200, { "Content-Type": "text/html" });
        res.end(rewritten);
      } catch {
        res.writeHead(404);
        res.end("Player not found");
      }
      return;
    }
    if (url.pathname.startsWith("/video/") && dir) {
      const filename = decodeURIComponent(url.pathname.slice("/video/".length));
      const filePath = pathMod.join(dir, pathMod.basename(filename));
      const ext = pathMod.extname(filePath).toLowerCase();
      const contentType = mime[ext] || "application/octet-stream";
      let stat;
      try {
        stat = fs.statSync(filePath);
      } catch {
        res.writeHead(404);
        res.end("Not found");
        return;
      }
      const rangeHeader = req.headers.range;
      if (rangeHeader) {
        const match = rangeHeader.match(/bytes=(\d+)-(\d*)/);
        if (match) {
          const start = parseInt(match[1], 10);
          const end = match[2] ? parseInt(match[2], 10) : stat.size - 1;
          if (start >= stat.size) {
            res.writeHead(416, { "Content-Range": `bytes */${stat.size}` });
            res.end();
            return;
          }
          const clampedEnd = Math.min(end, stat.size - 1);
          res.writeHead(206, {
            "Content-Range": `bytes ${start}-${clampedEnd}/${stat.size}`,
            "Accept-Ranges": "bytes",
            "Content-Length": clampedEnd - start + 1,
            "Content-Type": contentType
          });
          fs.createReadStream(filePath, { start, end: clampedEnd }).pipe(res);
          return;
        }
      }
      res.writeHead(200, {
        "Content-Length": stat.size,
        "Content-Type": contentType,
        "Accept-Ranges": "bytes"
      });
      fs.createReadStream(filePath).pipe(res);
      return;
    }
    res.writeHead(404);
    res.end("Not found");
  });
  await new Promise((resolve) => {
    srv.listen(0, "127.0.0.1", () => {
      videoServerPort = srv.address().port;
      videoServerInstance = srv;
      console.error(`[assrt-mcp] Video player server started on port ${videoServerPort}`);
      resolve();
    });
  });
  return videoServerPort;
}
var PLAN_SYSTEM_PROMPT = `You are a Senior QA Engineer generating test cases for an AI browser agent. The agent can: navigate URLs, click buttons/links by text or selector, type into inputs, scroll, press keys, and make assertions. It CANNOT: resize the browser, test network errors, inspect CSS, or run JavaScript.

## Output Format
Generate test cases in this EXACT format:

#Case 1: [short action-oriented name]
[Step-by-step instructions the agent can execute. Be SPECIFIC about what to click, what to type, and what to verify.]

#Case 2: [short action-oriented name]
[Step-by-step instructions...]

## CRITICAL Rules for Executable Tests
1. **Each case must be SELF-CONTAINED** \u2014 do not assume previous cases ran. If a test needs login, include the login steps.
2. **Be specific about selectors** \u2014 say "click the Login button" not "navigate to login". Say "type test@email.com into the email field" not "fill in credentials".
3. **Verify observable things** \u2014 check for visible text, page titles, URLs, element presence. NOT for CSS, colors, performance, or responsive layout.
4. **Keep cases SHORT** \u2014 3-5 actions max per case. A focused test that passes is better than a complex one that fails.
5. **Avoid testing what you can't see** \u2014 don't generate cases for features behind authentication unless there's a visible signup/login form.
6. **Generate 5-8 cases max** \u2014 focused on the MOST IMPORTANT user flows visible on the page.`;
var DIAGNOSE_SYSTEM_PROMPT = `You are a senior QA engineer and debugging expert. You are given a failing test case report from an automated web testing agent. Your job is to:

1. **Diagnose** the root cause \u2014 is it a bug in the application, a flawed test, or an environment issue?
2. **Provide a fix** \u2014 give a concrete, actionable solution:
   - If the app has a bug: describe what the app should do differently
   - If the test is flawed: provide a corrected test scenario in the exact #Case format
   - If it's an environment issue: explain what needs to change
3. **Provide a corrected test scenario** if the test itself needs adjustment

## Output Format

### Root Cause
[1-2 sentences identifying the core issue]

### Analysis
[3-5 sentences explaining what went wrong and why]

### Recommended Fix
[Concrete steps to fix the issue]

### Corrected Test Scenario
#Case 1: [corrected case name]
[corrected steps that will pass]

## Rules
- Be specific \u2014 reference actual elements, URLs, error messages from the report
- If the test failed because a feature doesn't exist, say so clearly
- If the test steps are valid but the app is broken, focus on the app issue
- Keep it concise and actionable \u2014 no filler`;
var lastVideoFile = null;
var SERVER_INSTRUCTIONS = `You are connected to Assrt, an AI-powered QA testing server that runs real browser tests against web applications.

## When to use Assrt

**Proactively use Assrt after any user-facing change.** Do not wait for the user to ask for testing. Specifically:

1. **After implementing a feature or bug fix** that touches UI, routes, forms, or user flows: run \`assrt_test\` against the local dev server to verify the change works end-to-end in a real browser.
2. **Before committing code**: if the changes affect anything a user would see or interact with, generate a quick test with \`assrt_plan\` or write a targeted test case and run it with \`assrt_test\`.
3. **When a test fails**: use \`assrt_diagnose\` to understand root cause before attempting a fix. Do not guess.

## How to use the tools

- **assrt_test**: The primary tool. Pass a URL and either a \`plan\` (text) or a \`scenarioId\` (UUID from a previous run). Returns structured pass/fail results with screenshots.
- **assrt_plan**: Use when you need test cases but don't have them. Navigates to the URL, analyzes the page, and generates executable test scenarios.
- **assrt_diagnose**: Use after a failed test. Pass the URL, the scenario that failed, and the error. Returns root cause analysis and a corrected test.

## Scenario files

After \`assrt_test\` runs, the test plan is saved to \`/tmp/assrt/scenario.md\` and results to \`/tmp/assrt/results/latest.json\`. You can:
- **Read** \`/tmp/assrt/scenario.md\` to see the current plan
- **Edit** \`/tmp/assrt/scenario.md\` to modify test cases; changes auto-sync to cloud storage
- **Read** \`/tmp/assrt/results/latest.json\` to review the last run's results
- **Read** \`/tmp/assrt/scenario.json\` for scenario metadata (ID, name, URL)

Every test run is auto-saved with a unique scenario ID (UUID). Use this ID to re-run the same scenario later: \`assrt_test({url, scenarioId: "..."})\`.

## Extension mode (reuse existing Chrome)

Pass \`extension: true\` to connect to the user's running Chrome (with their logins, cookies, tabs) instead of launching a new browser. On first use, if no token is saved, the response will contain setup instructions and an \`extension_token_required\` error. Ask the user to paste the token, then retry with \`extensionToken\` set. The token is saved automatically for future runs.

## Important

- Always include the correct local dev server URL. Check package.json scripts or running processes to find it.
- Test plans use \`#Case N: name\` format. Each case should be self-contained (3-5 steps).
- The browser runs headless by default at 1600x900. Pass \`headed: true\` to \`assrt_test\` (or set \`ASSRT_HEADED=1\`) to launch a visible browser window, useful when debugging a failing test locally. Screenshots are returned as images in the response.
- If the dev server is not running, start it first before calling assrt_test.

## Non-blocking CLI alternative

The MCP tools (\`assrt_test\`, \`assrt_plan\`) block the conversation until they finish. To run tests without blocking, use the \`assrt\` CLI via the Bash tool with \`run_in_background: true\`:

\`\`\`bash
npx assrt run --url http://localhost:3000 --extension --video --plan "#Case: Login flow
- Navigate to the login page
- Enter test credentials
- Verify dashboard loads" --json
\`\`\`

Key flags: \`--video\` records a video and auto-opens the player, \`--no-auto-open\` records without opening, \`--extension\` reuses existing Chrome, \`--json\` outputs structured results (includes \`videoPlayerUrl\`).

Use this when you want to continue working while tests run in the background.`;
var server = new McpServer(
  { name: "assrt", version: "0.2.0" },
  { instructions: SERVER_INSTRUCTIONS }
);
server.tool(
  "assrt_test",
  "Run AI-powered QA test scenarios against a URL. Returns a structured report with pass/fail results, assertions, and improvement suggestions.",
  {
    url: z.string().optional().describe("URL to test (e.g. http://localhost:3000). Optional when continuing in an existing browser session."),
    plan: z.string().optional().describe("Test scenarios in text format. Use #Case N: format for multiple scenarios. Either plan or scenarioId is required."),
    scenarioId: z.string().optional().describe("Load a saved scenario by its UUID instead of providing plan text. Get this ID from a previous assrt_test run or the Assrt web app."),
    scenarioName: z.string().optional().describe("Human-readable name for saving this scenario (e.g. 'checkout flow'). Used when auto-saving new scenarios."),
    passCriteria: z.string().optional().describe("Explicit pass/fail criteria the agent MUST verify. Free text describing success conditions (e.g. 'Cart total shows $42.99', 'User is redirected to /dashboard', 'Error toast does NOT appear'). The test fails if any criterion is not met."),
    variables: z.record(z.string(), z.string()).optional().describe('Key/value pairs for parameterized tests. Variables are interpolated into the plan text as {{KEY}} and also shown to the agent. Example: {"EMAIL": "test@example.com", "SKU": "PROD-001"}'),
    timeout: z.number().optional().describe("Maximum seconds before the test run is aborted (default: no limit). On timeout the response includes whatever scenarios completed plus a synthetic 'Timeout' marker scenario; completed scenarios keep their real per-assertion pass/fail data. Set comfortably above the expected runtime (5 cases on a long page typically need 600+ seconds)."),
    stopOnFirstFailure: z.boolean().optional().describe("When true, abort remaining scenarios as soon as one scenario reports passed:false. The response includes the failed scenario plus any prior passing scenarios. Defaults to false (run all scenarios). Recommended for agent/CI pipelines that want fail-fast."),
    viewport: z.union([
      z.string().describe("Viewport preset: 'mobile' (375x812) or 'desktop' (1440x900)"),
      z.object({ width: z.number(), height: z.number() }).describe("Explicit viewport dimensions")
    ]).optional().describe("Browser viewport size. Pass a preset string ('mobile', 'desktop') or explicit {width, height}."),
    tags: z.array(z.string()).optional().describe("Tags for organizing scenarios (e.g. ['smoke', 'checkout', 'regression']). Saved with the scenario for filtering."),
    model: z.string().optional().describe("LLM model override. Default depends on provider: claude-haiku-4-5-20251001 for Anthropic, gemini-flash-latest for Gemini."),
    autoOpenPlayer: z.boolean().optional().describe("Auto-open the video player in the browser when test completes (default: true)"),
    headed: z.boolean().optional().describe("Launch a visible (headed) browser window instead of headless. Defaults to headless, or the ASSRT_HEADED env var if set."),
    isolated: z.boolean().optional().describe("When true, keep the browser profile in memory only (no disk persistence). When false (default), persist cookies, localStorage, and logins to ~/.assrt/browser-profile across test runs."),
    keepBrowserOpen: z.boolean().optional().describe("When true, leave the browser window open after the test finishes instead of closing it. Useful for manual inspection or follow-up testing. Defaults to false."),
    extension: z.boolean().optional().describe("When true, connect to your existing Chrome browser instance instead of launching a new one. Uses Playwright's --extension mode via Chrome DevTools Protocol."),
    extensionToken: z.string().optional().describe("Playwright extension token for bypassing the Chrome approval dialog. Required on first use of extension mode. The token is saved automatically for future runs."),
    managed: z.boolean().optional().describe("When true, launch a managed Google Chrome with --remote-debugging-port and attach Playwright MCP via CDP. Required when this run will use assrt_seed_* tools to inject cookies/localStorage/IndexedDB. Defaults to false (uses Playwright's bundled Chromium with no externally reachable CDP).")
  },
  async ({ url: urlParam, plan, scenarioId, scenarioName, passCriteria: passCriteriaParam, variables: variablesParam, timeout, stopOnFirstFailure, viewport, tags: tagsParam, model, autoOpenPlayer, headed, isolated, keepBrowserOpen, extension, extensionToken, managed }) => {
    let passCriteria = passCriteriaParam;
    let variables = variablesParam;
    let tags = tagsParam;
    const url = urlParam || "";
    if (!url && (!sharedBrowser || !sharedBrowser.isConnected)) {
      return { content: [{ type: "text", text: JSON.stringify({ error: "url is required when there is no existing browser session to continue." }) }] };
    }
    let resolvedPlan;
    let resolvedScenarioId = scenarioId;
    if (scenarioId && plan) {
      return { content: [{ type: "text", text: JSON.stringify({ error: "Provide either plan or scenarioId, not both." }) }] };
    }
    if (scenarioId) {
      const stored = await fetchScenario(scenarioId);
      if (!stored) {
        return { content: [{ type: "text", text: JSON.stringify({ error: `Scenario ${scenarioId} not found.` }) }] };
      }
      resolvedPlan = stored.plan;
      if (!passCriteria && stored.passCriteria) passCriteria = stored.passCriteria;
      if ((!variables || Object.keys(variables).length === 0) && stored.variables) variables = stored.variables;
      if ((!tags || tags.length === 0) && stored.tags) tags = stored.tags;
      console.error(`[assrt_test] Loaded scenario ${scenarioId.slice(0, 8)}... (${stored.name || "unnamed"})`);
    } else if (plan) {
      resolvedPlan = plan;
    } else {
      return { content: [{ type: "text", text: JSON.stringify({ error: "Either plan or scenarioId is required." }) }] };
    }
    writeScenarioFile(resolvedPlan, {
      id: resolvedScenarioId || "unsaved",
      name: scenarioName,
      url
    });
    const shouldAutoOpen = autoOpenPlayer !== false;
    const autoSave = !process.env.ASSRT_NO_SAVE;
    const credential = getCredential();
    if (autoSave && !resolvedScenarioId) {
      try {
        resolvedScenarioId = await saveScenario({
          plan: resolvedPlan,
          name: scenarioName,
          url,
          passCriteria,
          variables,
          tags,
          createdFrom: "mcp"
        });
        writeScenarioFile(resolvedPlan, { id: resolvedScenarioId, name: scenarioName, url });
        console.error(`[assrt_test] Pre-saved scenario as ${resolvedScenarioId.slice(0, 8)}...`);
      } catch (err) {
        console.error("[assrt_test] Pre-save failed:", err.message);
      }
    }
    const crypto = await import("crypto");
    const runId = crypto.randomUUID();
    const runDir = join3(tmpdir(), "assrt", runId);
    const screenshotDir = join3(runDir, "screenshots");
    mkdirSync3(screenshotDir, { recursive: true });
    const logs = [];
    const allEvents = [];
    const improvements = [];
    const screenshots = [];
    let currentStep = 0;
    let currentAction = "";
    let currentDescription = "";
    let screenshotIndex = 0;
    const emit = (type, data) => {
      const time = (/* @__PURE__ */ new Date()).toISOString();
      allEvents.push({ time, type, data: type === "screenshot" ? { step: currentStep, action: currentAction } : data });
      if (type === "status") logs.push(`[${time}] [status] ${data.message}`);
      else if (type === "step") {
        currentStep = data.id || currentStep;
        currentAction = data.action || "";
        currentDescription = data.description || "";
        logs.push(`[${time}] [step ${currentStep}] (${currentAction}) ${currentDescription} \u2014 ${data.status || "running"}`);
      } else if (type === "reasoning") {
        logs.push(`[${time}] [reasoning] ${data.text}`);
      } else if (type === "assertion") {
        const icon = data.passed ? "PASS" : "FAIL";
        logs.push(`[${time}] [${icon}] ${data.description}${data.evidence ? ` \u2014 ${data.evidence}` : ""}`);
      } else if (type === "scenario_start") {
        logs.push(`[${time}] [scenario_start] ${data.name}`);
      } else if (type === "scenario_complete") {
        const result = data.passed ? "PASSED" : "FAILED";
        logs.push(`[${time}] [${result}] ${data.name}`);
      } else if (type === "improvement_suggestion") {
        logs.push(`[${time}] [issue] ${data.severity}: ${data.title} \u2014 ${data.description}`);
        improvements.push({ title: data.title, severity: data.severity, description: data.description, suggestion: data.suggestion });
      } else if (type === "screenshot" && data.base64) {
        const filename = `${String(screenshotIndex).padStart(2, "0")}_step${currentStep}_${currentAction || "init"}.png`;
        const filepath = join3(screenshotDir, filename);
        try {
          writeFileSync3(filepath, Buffer.from(data.base64, "base64"));
        } catch {
        }
        screenshotIndex++;
        const last = screenshots[screenshots.length - 1];
        if (last && last.step === currentStep) {
          last.base64 = data.base64;
          last.file = filepath;
        } else {
          screenshots.push({
            step: currentStep,
            action: currentAction,
            description: currentDescription,
            base64: data.base64,
            file: filepath
          });
        }
      }
      if (type === "status" || type === "scenario_start") {
        server.server.sendLoggingMessage({
          level: "info",
          data: type === "status" ? data.message : `Starting scenario: ${data.name}`
        });
      }
    };
    const t0 = Date.now();
    const videoDir = join3(runDir, "video");
    const agentMode = "local";
    const headedResolved = headed ?? (process.env.ASSRT_HEADED === "1" || process.env.ASSRT_HEADED === "true");
    const isolatedResolved = isolated ?? (process.env.ASSRT_ISOLATED === "1" || process.env.ASSRT_ISOLATED === "true");
    if (agentMode === "local") {
      if (sharedBrowser && sharedBrowser.isConnected) {
        const alive = await sharedBrowser.isAlive();
        if (!alive) {
          console.error("[server] shared browser failed health check, closing and creating fresh instance");
          try {
            await sharedBrowser.close();
          } catch {
          }
          sharedBrowser = null;
        }
      }
      if (!sharedBrowser || !sharedBrowser.isConnected) {
        sharedBrowser = new McpBrowserManager();
      }
    }
    const extensionResolved = extension ?? false;
    const managedResolved = managed ?? (process.env.ASSRT_MANAGED_CHROME === "1" || process.env.ASSRT_MANAGED_CHROME === "true") ?? !!sharedBrowser?.getCdpUrl();
    const agent = new TestAgent(credential.token, emit, model, credential.provider, null, agentMode, credential.type, videoDir, headedResolved, isolatedResolved, agentMode === "local" ? sharedBrowser : void 0, extensionResolved, extensionToken, managedResolved);
    let videoFilesBefore = [];
    if (agentMode === "local" && sharedBrowser && !sharedBrowser.isConnected) {
      try {
        await sharedBrowser.launchLocal(videoDir, headedResolved, isolatedResolved, extensionResolved, extensionToken, managedResolved);
      } catch (err) {
        if (err instanceof ExtensionTokenRequired) {
          return { content: [{ type: "text", text: JSON.stringify({
            error: "extension_token_required",
            message: err.message,
            hint: "Ask the user to paste the token, then call assrt_test again with extensionToken parameter set to the token value."
          }, null, 2) }] };
        }
        throw err;
      }
    }
    if (agentMode === "local" && sharedBrowser && sharedBrowser.isConnected) {
      mkdirSync3(videoDir, { recursive: true });
      const playwrightOutputDir = sharedBrowser.getOutputDir();
      if (playwrightOutputDir) {
        try {
          videoFilesBefore = readdirSync(playwrightOutputDir).filter((f) => f.endsWith(".webm"));
        } catch {
        }
      }
      await sharedBrowser.startVideo();
    }
    const runOptions = { passCriteria, variables, timeout, viewport, stopOnFirstFailure };
    let report;
    if (timeout && timeout > 0) {
      const timeoutMs = timeout * 1e3;
      const timeoutPromise = new Promise(
        (_, reject) => setTimeout(() => reject(new Error(`Test run exceeded timeout of ${timeout}s`)), timeoutMs)
      );
      try {
        report = await Promise.race([agent.run(url, resolvedPlan, runOptions), timeoutPromise]);
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        const timeoutScenario = {
          name: "Timeout",
          passed: false,
          steps: [],
          assertions: [{ description: `Completed within ${timeout}s`, passed: false, evidence: errMsg }],
          summary: errMsg,
          duration: timeout * 1e3
        };
        const partial = agent.getPartialReport();
        if (partial && partial.scenarios.length > 0) {
          const scenarios = [...partial.scenarios, timeoutScenario];
          report = {
            url,
            scenarios,
            totalDuration: timeout * 1e3,
            passedCount: scenarios.filter((s) => s.passed).length,
            failedCount: scenarios.filter((s) => !s.passed).length,
            generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            aborted: true,
            abortReason: errMsg
          };
        } else {
          report = {
            url,
            scenarios: [timeoutScenario],
            totalDuration: timeout * 1e3,
            passedCount: 0,
            failedCount: 1,
            generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            aborted: true,
            abortReason: errMsg
          };
        }
      }
    } else {
      report = await agent.run(url, resolvedPlan, runOptions);
    }
    if (agentMode === "local" && sharedBrowser) {
      await sharedBrowser.stopVideo();
      const playwrightOutputDir = sharedBrowser.getOutputDir();
      if (playwrightOutputDir) {
        try {
          const { copyFileSync } = await import("fs");
          const videoFilesAfter = readdirSync(playwrightOutputDir).filter((f) => f.endsWith(".webm"));
          const newVideoFiles = videoFilesAfter.filter((f) => !videoFilesBefore.includes(f));
          if (newVideoFiles.length > 0) {
            const srcPath = join3(playwrightOutputDir, newVideoFiles[0]);
            const destPath = join3(videoDir, "recording.webm");
            copyFileSync(srcPath, destPath);
            console.error(`[assrt_test] video copied: ${srcPath} -> ${destPath}`);
          }
        } catch (err) {
          console.error(`[assrt_test] video copy failed: ${err.message}`);
        }
      }
      console.error("[assrt_test] browser kept alive for reuse");
    } else {
      await agent.close({ keepBrowserOpen: !!keepBrowserOpen });
    }
    const logContent = logs.join("\n");
    const logFile = join3(runDir, "execution.log");
    try {
      writeFileSync3(logFile, logContent);
    } catch {
    }
    const eventsFile = join3(runDir, "events.json");
    try {
      writeFileSync3(eventsFile, JSON.stringify(allEvents, null, 2));
    } catch {
    }
    let videoFile = null;
    let videoPlayerFile = null;
    let videoPlayerUrl = null;
    try {
      const videoFiles = readdirSync(videoDir).filter((f) => f.endsWith(".webm"));
      if (videoFiles.length > 0) {
        videoFile = join3(videoDir, videoFiles[0]);
        lastVideoFile = videoFile;
        videoPlayerFile = join3(videoDir, "player.html");
        writeFileSync3(videoPlayerFile, generateVideoPlayerHtml(
          basename(videoFiles[0]),
          url,
          report.passedCount,
          report.failedCount,
          +(report.totalDuration / 1e3).toFixed(1)
        ));
        try {
          const port = await ensureVideoServer();
          videoPlayerUrl = `http://127.0.0.1:${port}/player.html?dir=${encodeURIComponent(videoDir)}`;
          if (shouldAutoOpen) {
            try {
              execSync(`open "${videoPlayerUrl}"`);
            } catch {
            }
          }
        } catch {
        }
      }
    } catch {
    }
    const summary = {
      passed: report.failedCount === 0,
      passedCount: report.passedCount,
      failedCount: report.failedCount,
      duration: +(report.totalDuration / 1e3).toFixed(1),
      ...report.aborted ? { aborted: true, abortReason: report.abortReason } : {},
      ...passCriteria && { passCriteria },
      ...variables && Object.keys(variables).length > 0 && { variables },
      ...tags && tags.length > 0 && { tags },
      ...viewport && { viewport },
      ...timeout && { timeout },
      screenshotCount: screenshots.length,
      artifactsDir: runDir,
      logFile,
      videoFile,
      videoPlayerFile,
      videoPlayerUrl,
      scenarios: report.scenarios.map((s) => ({
        name: s.name,
        passed: s.passed,
        summary: s.summary,
        assertions: s.assertions.map((a) => ({
          description: a.description,
          passed: a.passed,
          evidence: a.evidence
        }))
      })),
      improvements
    };
    const screenshotFiles = screenshots.map((ss) => ({
      step: ss.step,
      action: ss.action,
      description: ss.description,
      file: ss.file
    }));
    summary.screenshots = screenshotFiles;
    if (resolvedScenarioId && !resolvedScenarioId.startsWith("local-")) {
      const artifactNames = {};
      if (videoFile) artifactNames.video = basename(videoFile);
      if (screenshotFiles.length > 0) artifactNames.screenshots = screenshotFiles.map((s) => basename(s.file));
      artifactNames.log = "execution.log";
      const cloudUrls = buildCloudUrls(resolvedScenarioId, runId, artifactNames);
      summary.cloudUrls = cloudUrls;
    }
    const { latestPath, runPath } = writeResultsFile(runId, summary);
    summary.resultsFile = latestPath;
    summary.runResultsFile = runPath;
    summary.scenarioFile = PATHS.scenarioFile;
    summary.scenarioMetaFile = PATHS.scenarioMeta;
    const currentPlan = readScenarioFile();
    if (currentPlan && currentPlan !== resolvedPlan) {
      console.error("[assrt_test] Scenario was edited during run, using updated plan for save");
      resolvedPlan = currentPlan;
    }
    const content = [
      { type: "text", text: JSON.stringify(summary, null, 2) }
    ];
    if (resolvedScenarioId) {
      summary.scenarioId = resolvedScenarioId;
    }
    if (resolvedScenarioId && !resolvedScenarioId.startsWith("local-")) {
      if (currentPlan && currentPlan !== resolvedPlan) {
        updateScenario(resolvedScenarioId, { plan: resolvedPlan }).catch(
          (err) => console.error("[assrt_test] Async scenario update failed:", err.message)
        );
      }
      saveScenarioRun(resolvedScenarioId, {
        planSnapshot: resolvedPlan,
        url,
        model: agent.model,
        status: report.failedCount === 0 ? "passed" : "failed",
        passedCount: report.passedCount,
        failedCount: report.failedCount,
        totalDuration: report.totalDuration,
        reportJson: summary
      }).then((savedRunId) => {
        if (!savedRunId) return;
        const files = [];
        if (videoFile) files.push({ name: basename(videoFile), path: videoFile, type: "video/webm" });
        if (logFile) files.push({ name: "execution.log", path: logFile, type: "text/plain" });
        for (const ss of screenshotFiles) {
          files.push({ name: basename(ss.file), path: ss.file, type: "image/png" });
        }
        if (files.length > 0) {
          uploadArtifacts(resolvedScenarioId, savedRunId, files).catch(
            (err) => console.error("[assrt_test] Artifact upload failed:", err.message)
          );
        }
      }).catch((err) => console.error("[assrt_test] Async run save failed:", err.message));
    }
    trackEvent("assrt_test_run", {
      url,
      model: agent.model,
      provider: agent.provider,
      passed: report.failedCount === 0,
      passedCount: report.passedCount,
      failedCount: report.failedCount,
      duration_s: +((Date.now() - t0) / 1e3).toFixed(1),
      screenshotCount: screenshots.length,
      scenarioCount: report.scenarios.length,
      scenarioId: resolvedScenarioId?.slice(0, 8),
      source: "mcp"
    });
    return { content };
  }
);
server.tool(
  "assrt_plan",
  "Auto-generate QA test scenarios by analyzing a URL. Launches a browser, takes screenshots, and uses AI to create executable test cases.",
  {
    url: z.string().describe("URL to analyze (e.g. http://localhost:3000)"),
    model: z.string().optional().describe("LLM model override for plan generation")
  },
  async ({ url, model }) => {
    const t0 = Date.now();
    const credential = getCredential();
    const resolvedModel = model || defaultModelFor(credential.provider);
    const browser = new McpBrowserManager();
    try {
      server.server.sendLoggingMessage({ level: "info", data: "Launching local browser..." });
      await browser.launchLocal();
      server.server.sendLoggingMessage({ level: "info", data: `Navigating to ${url}...` });
      await browser.navigate(url);
      const screenshot1 = await browser.screenshot();
      const snapshotText1 = await browser.snapshot();
      await browser.scroll(0, 800);
      await new Promise((r) => setTimeout(r, 500));
      const screenshot2 = await browser.screenshot();
      const snapshotText2 = await browser.snapshot();
      await browser.scroll(0, 800);
      await new Promise((r) => setTimeout(r, 500));
      const screenshot3 = await browser.screenshot();
      const snapshotText3 = await browser.snapshot();
      await browser.close();
      const allText = [snapshotText1, snapshotText2, snapshotText3].join("\n\n").slice(0, 8e3);
      server.server.sendLoggingMessage({ level: "info", data: `Generating test plan with ${credential.provider} (${resolvedModel})...` });
      const userText = `Analyze this web application and generate a comprehensive test plan.

**URL:** ${url}

**Visible Text Content:**
${allText}

Based on the screenshots and page analysis above, generate comprehensive test cases for this web application.`;
      const screenshots = [screenshot1, screenshot2, screenshot3].filter((s) => !!s);
      let plan;
      if (credential.provider === "gemini") {
        const gemini = await geminiFromCredential(credential);
        const parts = [];
        for (const img of screenshots) {
          parts.push({ inlineData: { mimeType: "image/jpeg", data: img } });
        }
        parts.push({ text: userText });
        const response = await gemini.models.generateContent({
          model: resolvedModel,
          contents: [{ role: "user", parts }],
          config: { systemInstruction: PLAN_SYSTEM_PROMPT }
        });
        const candidate = response?.candidates?.[0];
        plan = (candidate?.content?.parts || []).filter((p) => typeof p.text === "string").map((p) => p.text).join("");
      } else {
        const anthropic = await anthropicFromCredential(credential);
        const contentParts = [];
        for (const img of screenshots) {
          contentParts.push({
            type: "image",
            source: { type: "base64", media_type: "image/jpeg", data: img }
          });
        }
        contentParts.push({ type: "text", text: userText });
        const response = await anthropic.messages.create({
          model: resolvedModel,
          max_tokens: 4096,
          system: PLAN_SYSTEM_PROMPT,
          messages: [{ role: "user", content: contentParts }]
        });
        plan = response.content.filter((b) => b.type === "text").map((b) => b.text).join("");
      }
      trackEvent("assrt_plan_run", {
        url,
        model: resolvedModel,
        provider: credential.provider,
        duration_s: +((Date.now() - t0) / 1e3).toFixed(1),
        source: "mcp"
      });
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({ plan, url }, null, 2)
          }
        ]
      };
    } catch (err) {
      try {
        await browser.close();
      } catch {
      }
      trackEvent("assrt_plan_error", { url, error: err.message?.slice(0, 200), source: "mcp" });
      throw err;
    }
  }
);
server.tool(
  "assrt_diagnose",
  "Diagnose a failed test scenario. Analyzes the failure and suggests fixes for both application bugs and flawed tests.",
  {
    url: z.string().describe("URL that was tested"),
    scenario: z.string().describe("The test scenario that failed"),
    error: z.string().describe("The failure description, evidence, or error message")
  },
  async ({ url, scenario, error }) => {
    const t0 = Date.now();
    const credential = getCredential();
    const resolvedModel = defaultModelFor(credential.provider);
    const debugPrompt = `## Failed Test Report

**URL:** ${url}

**Test Scenario:**
${scenario}

**Failure:**
${error}

Please diagnose this failure and provide a corrected test scenario.`;
    let diagnosis;
    if (credential.provider === "gemini") {
      const gemini = await geminiFromCredential(credential);
      const response = await gemini.models.generateContent({
        model: resolvedModel,
        contents: [{ role: "user", parts: [{ text: debugPrompt }] }],
        config: { systemInstruction: DIAGNOSE_SYSTEM_PROMPT }
      });
      const candidate = response?.candidates?.[0];
      diagnosis = (candidate?.content?.parts || []).filter((p) => typeof p.text === "string").map((p) => p.text).join("");
    } else {
      const anthropic = await anthropicFromCredential(credential);
      const response = await anthropic.messages.create({
        model: resolvedModel,
        max_tokens: 4096,
        system: DIAGNOSE_SYSTEM_PROMPT,
        messages: [{ role: "user", content: debugPrompt }]
      });
      diagnosis = response.content.filter((b) => b.type === "text").map((b) => b.text).join("");
    }
    trackEvent("assrt_diagnose_run", {
      url,
      model: resolvedModel,
      provider: credential.provider,
      duration_s: +((Date.now() - t0) / 1e3).toFixed(1),
      source: "mcp"
    });
    return {
      content: [
        {
          type: "text",
          text: JSON.stringify({ diagnosis, url, scenario, model: resolvedModel, provider: credential.provider }, null, 2)
        }
      ]
    };
  }
);
async function resolveCdpUrl(explicit) {
  if (explicit && explicit.trim()) return { cdpUrl: explicit.trim(), spawned: false };
  if (!sharedBrowser) sharedBrowser = new McpBrowserManager();
  const existing = sharedBrowser.getCdpUrl();
  if (existing) return { cdpUrl: existing, spawned: false };
  const handle = await sharedBrowser.ensureManagedChrome();
  return { cdpUrl: handle.cdpUrl, spawned: !handle.reused };
}
function registerSeedTool(kind, opts) {
  server.tool(
    opts.name,
    opts.description,
    {
      source: z.string().describe(
        "Source profile spec: '<browser>:<profile>'. Browsers: chrome, arc, brave, edge. Examples: 'chrome:Default', 'arc:Default', 'brave:Profile 1'. The source browser must be CLOSED \u2014 its on-disk storage files are locked while it runs."
      ),
      [opts.filterArg.name]: z.string().optional().describe(opts.filterArg.description),
      ...opts.supportsLoadWait ? { loadWait: z.number().optional().describe("Seconds to wait after opening each tab before injecting (default 4). Increase for slow-loading origins.") } : {},
      cdpUrl: z.string().optional().describe("Override the target CDP HTTP endpoint (e.g. http://127.0.0.1:9655). Defaults to ASSRT_CDP_ENDPOINT or the managed browser's endpoint."),
      verbose: z.boolean().optional().describe("Verbose CLI output (passes -v).")
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async (args) => {
      const t0 = Date.now();
      let resolved;
      try {
        resolved = await resolveCdpUrl(args.cdpUrl);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        return {
          content: [{ type: "text", text: JSON.stringify({ ok: false, error: `Failed to acquire CDP endpoint: ${message}` }, null, 2) }],
          isError: true
        };
      }
      const result = await seed(kind, {
        source: args.source,
        cdpUrl: resolved.cdpUrl,
        filter: args[opts.filterArg.name],
        loadWait: args.loadWait,
        verbose: args.verbose
      });
      trackEvent(`assrt_seed_${kind}`, {
        source_profile: String(args.source).slice(0, 60),
        ok: result.ok,
        duration_s: +((Date.now() - t0) / 1e3).toFixed(1),
        chrome_spawned: resolved.spawned,
        source: "mcp"
      });
      return {
        content: [{
          type: "text",
          text: JSON.stringify({
            ok: result.ok,
            kind: result.kind,
            cdpUrl: resolved.cdpUrl,
            spawnedManagedChrome: resolved.spawned,
            returncode: result.returncode,
            stdout: result.stdout,
            stderr: result.stderr,
            ...result.error ? { error: result.error } : {}
          }, null, 2)
        }],
        ...result.ok ? {} : { isError: true }
      };
    }
  );
}
registerSeedTool("cookies", {
  name: "assrt_seed_cookies",
  description: "Import cookies from a local browser profile (Chrome/Arc/Brave/Edge) into the test browser via CDP. Use to load a user's logged-in session into the test browser before assrt_test. Strongly recommended to scope with `domains` \u2014 cookies are auth secrets.",
  filterArg: {
    name: "domains",
    description: "Comma-separated host_key substrings to include (e.g. 'github.com,linear.app'). Omit to copy ALL cookies (not recommended)."
  },
  supportsLoadWait: false
});
registerSeedTool("localstorage", {
  name: "assrt_seed_localstorage",
  description: "Import localStorage from a local browser profile into the test browser. Opens a tab per origin in the test browser, runs localStorage.setItem() via CDP, closes the tab. Use for sites that store auth/state in localStorage (ChatGPT, Notion, Linear, X.com).",
  filterArg: {
    name: "origins",
    description: "Comma-separated host substrings (e.g. 'chatgpt.com,notion.so'). Omit to copy ALL origins (not recommended)."
  },
  supportsLoadWait: true
});
registerSeedTool("indexeddb", {
  name: "assrt_seed_indexeddb",
  description: "Import IndexedDB databases from a local browser profile into the test browser. For each origin: opens a tab, lets the page bootstrap its IDB schema, then replays records via CDP. Use for sites that store auth/session/sync state in IDB (Linear, Figma, Slack web, Excalidraw, Notion offline).",
  filterArg: {
    name: "origins",
    description: "Comma-separated host substrings (e.g. 'linear.app,figma.com'). Omit to copy ALL origins with IDB data (not recommended)."
  },
  supportsLoadWait: true
});
var GEMINI_VIDEO_MODEL = "gemini-3.1-flash-lite-preview";
if (process.env.GEMINI_API_KEY) {
  server.tool(
    "assrt_analyze_video",
    "Analyze the most recent test recording video using Gemini vision. Ask questions about what happened during the test, verify visual states, or get a summary of the browser session.",
    {
      prompt: z.string().describe("What to analyze in the video (e.g. 'Did the login form appear?', 'Summarize what happened', 'Was there a visual error?')"),
      videoPath: z.string().optional().describe("Path to a specific .webm video file. If omitted, uses the most recent assrt_test recording.")
    },
    async ({ prompt, videoPath }) => {
      const apiKey = process.env.GEMINI_API_KEY;
      const filePath = videoPath || lastVideoFile;
      if (!filePath) {
        return {
          content: [{
            type: "text",
            text: JSON.stringify({ error: "No video available. Run assrt_test first to record a test session, or provide a videoPath." })
          }],
          isError: true
        };
      }
      let videoBuffer;
      try {
        videoBuffer = readFileSync3(filePath);
      } catch {
        return {
          content: [{
            type: "text",
            text: JSON.stringify({ error: `Could not read video file: ${filePath}` })
          }],
          isError: true
        };
      }
      const videoBase64 = videoBuffer.toString("base64");
      const { GoogleGenAI } = await import("@google/genai");
      const genai = new GoogleGenAI({ apiKey });
      try {
        const response = await genai.models.generateContent({
          model: GEMINI_VIDEO_MODEL,
          contents: [
            {
              role: "user",
              parts: [
                {
                  inlineData: {
                    mimeType: "video/webm",
                    data: videoBase64
                  }
                },
                { text: prompt }
              ]
            }
          ]
        });
        const analysis = response.text ?? "";
        trackEvent("assrt_analyze_video", {
          prompt: prompt.slice(0, 200),
          videoPath: filePath,
          source: "mcp"
        });
        return {
          content: [{
            type: "text",
            text: JSON.stringify({ analysis, videoPath: filePath })
          }]
        };
      } catch (err) {
        return {
          content: [{
            type: "text",
            text: JSON.stringify({
              error: `Gemini API error: ${err instanceof Error ? err.message : "unknown error"}`,
              videoPath: filePath
            })
          }],
          isError: true
        };
      }
    }
  );
  console.error("[assrt-mcp] assrt_analyze_video tool registered (GEMINI_API_KEY found)");
} else {
  console.error("[assrt-mcp] assrt_analyze_video tool skipped (GEMINI_API_KEY not set)");
}
server.tool(
  "assrt_open_session",
  "Open a managed Chrome browser session. Returns a CDP endpoint that subsequent assrt_navigate, assrt_screenshot, assrt_seed_*, and assrt_test calls will reuse. Idempotent: if a session is already open it is returned as-is. Defaults to a visible (headed) Chrome window so the desktop user can watch what the agent is doing; pass headed: false for unattended/CI runs.",
  {
    headed: z.boolean().optional().describe("Launch a visible browser window. Defaults to true (visible). Pass false only for unattended/CI runs."),
    managed: z.boolean().optional().describe("When true (default), spawn a real Chrome with an externally reachable CDP port \u2014 required for assrt_seed_* tools. When false, Playwright launches its private Chromium with no CDP exposure.")
  },
  async ({ headed, managed }) => {
    try {
      if (!sharedBrowser) sharedBrowser = new McpBrowserManager();
      const reused = await sharedBrowser.launchLocal(
        void 0,
        headed ?? true,
        false,
        false,
        void 0,
        managed ?? true
      );
      const cdpUrl = sharedBrowser.getCdpUrl();
      const payload = {
        ok: true,
        reused,
        cdpUrl,
        headed: !!headed,
        managed: managed ?? true
      };
      return { content: [{ type: "text", text: JSON.stringify(payload, null, 2) }] };
    } catch (err) {
      const e = err;
      if (e instanceof ExtensionTokenRequired) {
        return { content: [{ type: "text", text: e.message }], isError: true };
      }
      return {
        content: [{ type: "text", text: `assrt_open_session failed: ${e.message}` }],
        isError: true
      };
    }
  }
);
server.tool(
  "assrt_close_session",
  "Close the managed Chrome session opened by assrt_open_session. No-op if no session is open. Pass keepBrowserOpen: true to detach without killing Chrome (useful when the user wants to continue browsing manually).",
  {
    keepBrowserOpen: z.boolean().optional().describe("Detach from the browser without killing it. Defaults to false.")
  },
  async ({ keepBrowserOpen }) => {
    if (!sharedBrowser) {
      return { content: [{ type: "text", text: JSON.stringify({ ok: true, hadSession: false }) }] };
    }
    try {
      await sharedBrowser.close({ keepBrowserOpen });
      sharedBrowser = null;
      return { content: [{ type: "text", text: JSON.stringify({ ok: true, hadSession: true, keptOpen: !!keepBrowserOpen }) }] };
    } catch (err) {
      return {
        content: [{ type: "text", text: `assrt_close_session failed: ${err.message}` }],
        isError: true
      };
    }
  }
);
server.tool(
  "assrt_navigate",
  "Navigate the active managed Chrome session to a URL. Auto-opens a session if none exists. Returns the page accessibility snapshot.",
  {
    url: z.string().describe("Destination URL (e.g. https://example.com or http://localhost:5173).")
  },
  async ({ url }) => {
    try {
      if (!sharedBrowser) {
        sharedBrowser = new McpBrowserManager();
        await sharedBrowser.launchLocal(void 0, true, false, false, void 0, true);
      }
      const snapshot = await sharedBrowser.navigate(url);
      return { content: [{ type: "text", text: snapshot }] };
    } catch (err) {
      return {
        content: [{ type: "text", text: `assrt_navigate failed: ${err.message}` }],
        isError: true
      };
    }
  }
);
server.tool(
  "assrt_screenshot",
  "Capture a screenshot of the active managed Chrome page. Returns a JPEG as an MCP image content block. Requires an open session (call assrt_open_session or assrt_navigate first).",
  {},
  async () => {
    if (!sharedBrowser) {
      return {
        content: [{ type: "text", text: "assrt_screenshot: no active session. Call assrt_open_session or assrt_navigate first." }],
        isError: true
      };
    }
    try {
      const b64 = await sharedBrowser.screenshot();
      if (!b64) {
        return { content: [{ type: "text", text: "assrt_screenshot: capture returned no image data." }], isError: true };
      }
      return { content: [{ type: "image", data: b64, mimeType: "image/jpeg" }] };
    } catch (err) {
      return {
        content: [{ type: "text", text: `assrt_screenshot failed: ${err.message}` }],
        isError: true
      };
    }
  }
);
console.error("[assrt-mcp] Phase 3 tools registered: assrt_open_session, assrt_close_session, assrt_navigate, assrt_screenshot");
async function main() {
  trackEvent("mcp_server_start", { source: "mcp" }, { dedupeDaily: true });
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("[assrt-mcp] server started, waiting for JSON-RPC on stdin");
  const gracefulShutdown = async (signal) => {
    console.error(`[assrt-mcp] received ${signal}, cleaning up...`);
    if (sharedBrowser) {
      try {
        await sharedBrowser.close();
        console.error("[assrt-mcp] shared browser closed");
      } catch (err) {
        console.error("[assrt-mcp] error closing shared browser:", err);
      }
      sharedBrowser = null;
    }
    await shutdownTelemetry();
    process.exit(0);
  };
  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.on("beforeExit", async () => {
    if (sharedBrowser) {
      try {
        await sharedBrowser.close();
      } catch {
      }
      sharedBrowser = null;
    }
  });
}
main().catch((err) => {
  console.error(`[assrt-mcp] fatal: ${err.message || err}`);
  process.exit(1);
});
